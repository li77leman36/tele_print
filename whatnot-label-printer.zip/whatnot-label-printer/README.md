# Whatnot Label Printer

Print labels from Whatnot live streams and orders on a cheap thermal label printer, from
anywhere, through Telegram.

- **Buyers and giveaway winners** print automatically as they happen on your live stream.
- **Chat messages** can print automatically, only when they start with a keyword, or with a
  🖨 button on each message.
- **Order labels:** in Seller Hub → Orders, a 🖨 Label button on each order prints its order
  number, item, buyer and "Item 1 of 3" on a label for each item.
- **A Telegram bot** turns text, photos or a scanned Pokémon card into a label, with
  borders, fonts, icons and QR codes.

```
 Chrome extension ──posts text──▶ private Telegram channel ──▶ printer bot on a Raspberry Pi ──▶ DYMO
 (on whatnot.com)   (sender bot)                                 (also takes direct messages)
```

The extension can't talk to the printer directly, and a Telegram bot never sees its own
messages. So the extension posts through a second "sender" bot into a channel, and the
printer bot prints every post in that channel.

## What's in here

| Folder | What it is |
|---|---|
| [`extension/`](extension) | Chrome extension (Manifest V3) that watches Whatnot and posts what to print. |
| [`bot/`](bot) | The Telegram printer bot (Python, standard library + Pillow), its Pi installer and the tuned DYMO driver. |

## Setup

You'll need a Raspberry Pi (a Pi Zero W is plenty), a USB label printer that CUPS can drive
(DYMO LabelWriter, Zebra ZPL/EPL), and a Telegram account.

### 1. Make two Telegram bots

In Telegram, talk to [@BotFather](https://t.me/BotFather) and send `/newbot` twice:

1. **The printer bot**, which runs on the Pi. Keep its token for `bot/config.env`.
2. **The sender bot**, which the extension posts through. Keep its token for the extension.

### 2. Set up the printer bot on the Pi

Follow [`bot/README.md`](bot/README.md): flash the SD card, copy `bot/` over, put the
printer bot's token in `config.env` and run `./install.sh`. Then message your printer bot
`/start`; the first person to do that becomes its owner.

### 3. Make the print channel

1. In Telegram, create a **private channel** (e.g. "Whatnot labels").
2. Add the **printer bot** as an admin. The easiest way is to open
   `https://t.me/YOUR_PRINTER_BOT?startchannel&admin=post_messages` on your phone and pick
   the channel. The bot then messages you the channel's ID, starting `-100`.
3. Add the **sender bot** the same way, with permission to post messages.

### 4. Install the Chrome extension

1. Copy `extension/local.example.js` to `extension/local.js` and fill in the sender bot's
   token and the channel ID. `local.js` isn't committed, so your token stays private. (You
   can also type them into the extension's popup instead.)
2. In Chrome, open `chrome://extensions`, turn on **Developer mode**, click **Load
   unpacked** and pick the `extension` folder.
3. Click the extension's icon, tick what you want printed, and press **Send test**.

## Using it

**The extension popup** has a master ON/OFF switch, then one switch for each of these:

| Option | What it prints |
|---|---|
| Buyers | The username of anyone who wins an auction or buys. |
| Giveaway winners | The username of giveaway winners. |
| Chat messages | Each new chat message (name, then message). Optionally only messages starting with a keyword like `!label`. |
| 🖨 button on chat messages | Click to print any single message. |
| Order labels | A 🖨 Label button on each order in Seller Hub → Orders. |

**The printer bot**: send it text (one label line per message line) or a photo, then use the
buttons under the preview: border, font (including a Pokémon-style font, see
[`bot/fonts`](bot/fonts)), icon, QR code, extra lines, today's date, copies and print.
Anyone can print text and photo labels. These commands are for the owner only:

| Command | What it does |
|---|---|
| `/card` | Scan a Pokémon card in any language and get an info label: English name, set, number and rarity. Uses the DeepSeek API. |
| `/deepseek KEY` | Save the DeepSeek API key (the message is deleted afterwards). |
| `/printer` | Switch printer, pick the label size, set darkness, flip, or add a new USB printer. |
| `/align` | Nudge where the design lands on the sticker. This is saved for each printer and size. |
| `/qr LINK` | Set the link used by the QR code button. |

## Privacy and secrets

None of these are committed. They live in git-ignored files:

- `bot/config.env`: the printer bot's token and printer settings.
- `bot/allowed_users.json`: the bot owner's Telegram ID.
- `bot/settings.json`: on the Pi; alignment, the print channel and the DeepSeek key.
- `extension/local.js`: the sender bot's token and the channel ID.

## Licence

MIT, see [`LICENSE`](LICENSE). Bundled third-party code keeps its own licence:
`bot/vendor/qrcode` is BSD (python-qrcode).

Not affiliated with Whatnot, DYMO, Nintendo or The Pokémon Company.
