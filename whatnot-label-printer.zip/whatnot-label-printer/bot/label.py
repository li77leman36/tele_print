"""Renders a bordered label (default 57x32 mm DYMO) and prints it through CUPS.

Same design and alignment as card-label/render_card_label.swift, which was tuned
on paper on the DYMO LabelWriter 400. Runs on the Pi (Pillow) and on the Mac.
"""
import math
import os
import re
import struct
import subprocess
import sys
import tempfile
import time
import zlib

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'vendor'))

from PIL import Image, ImageDraw, ImageFont, ImageOps

K = 12  # dots per mm (~300 dpi)

BORDERS = ['double', 'simple', 'bold', 'dashed', 'none']
BORDER_NAMES = {'double': 'Double', 'simple': 'Simple', 'bold': 'Bold',
                'dashed': 'Dashed', 'none': 'None'}

FONT_FILES = {
    'bold': ['/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
             '/System/Library/Fonts/Supplemental/Arial Bold.ttf',
             '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'],
    'regular': ['/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
                '/System/Library/Fonts/Supplemental/Arial.ttf',
                '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'],
}

# Font families: name -> (button name, {kind: files}). Liberation on the Pi, the Mac's equivalents
# as a fallback; Sans falls back to FONT_FILES.
_LIB, _MAC = '/usr/share/fonts/truetype/liberation/', '/System/Library/Fonts/Supplemental/'
FONTS = {
    'sans': ('Sans', FONT_FILES),
    'serif': ('Serif', {'bold': [_LIB + 'LiberationSerif-Bold.ttf', _MAC + 'Times New Roman Bold.ttf'],
                        'regular': [_LIB + 'LiberationSerif-Regular.ttf', _MAC + 'Times New Roman.ttf']}),
    'condensed': ('Condensed', {'bold': [_LIB + 'LiberationSansNarrow-Bold.ttf', _MAC + 'Arial Narrow Bold.ttf'],
                                'regular': [_LIB + 'LiberationSansNarrow-Regular.ttf', _MAC + 'Arial Narrow.ttf']}),
    'typewriter': ('Typewriter', {'bold': [_LIB + 'LiberationMono-Bold.ttf', _MAC + 'Courier New Bold.ttf'],
                                  'regular': [_LIB + 'LiberationMono-Regular.ttf', _MAC + 'Courier New.ttf']}),
    'italic': ('Italic', {'bold': [_LIB + 'LiberationSerif-BoldItalic.ttf', _MAC + 'Times New Roman Bold Italic.ttf'],
                          'regular': [_LIB + 'LiberationSerif-Italic.ttf', _MAC + 'Times New Roman Italic.ttf']}),
    # Logo-style lettering for the title only; smaller lines stay in Sans so they're easy to read
    'pokemon': ('Pokémon', {'bold': [os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fonts', 'PokemonSolid.ttf')],
                            'regular': FONT_FILES['regular']}),
}

ICONS = {'none': 'None', 'star': 'Star', 'heart': 'Heart', 'bolt': 'Lightning', 'pokeball': 'Poké Ball'}


class Layout:
    """Label geometry in mm. Offsets move the design to where the sticker really is
    (negative x = left, negative y = up)."""

    def __init__(self, cfg=None):
        cfg = cfg or {}
        f = lambda k, d: float(cfg.get(k, d))
        self.width, self.height = f('LABEL_WIDTH_MM', 57), f('LABEL_HEIGHT_MM', 32)
        self.border_w, self.border_h = f('BORDER_WIDTH_MM', 52), f('BORDER_HEIGHT_MM', 27)
        self.offset_x, self.offset_y = f('OFFSET_X_MM', -0.5), f('OFFSET_Y_MM', -2.0)


_font_cache = {}


def font(kind, size, family='sans'):
    key = (family, kind, int(size))
    if key not in _font_cache:
        files = FONTS.get(family, FONTS['sans'])[1][kind] + FONT_FILES[kind]
        path = next((p for p in files if os.path.exists(p)), None)
        if not path:
            raise RuntimeError('No %s font found; install fonts-liberation' % kind)
        _font_cache[key] = ImageFont.truetype(path, int(size))
    return _font_cache[key]


# Fonts whose letters are bigger than their nominal size (the Pokémon one overhangs a lot)
FONT_SCALE = {('pokemon', 'bold'): 0.78}


def _ink_width(f, text):
    """Width of what's actually drawn: some display fonts draw well past their advance width."""
    box = f.getbbox(text)
    return max(f.getlength(text), box[2] - box[0])


def _fit(kind, size, text, max_w, family='sans'):
    """Largest font up to `size` that fits `text` into max_w pixels."""
    size *= FONT_SCALE.get((family, kind), 1)
    f = font(kind, size, family)
    w = _ink_width(f, text)
    if w > max_w:
        f = font(kind, max(10, size * max_w / w), family)
    return f


def _draw_icon(d, name, cx, cy, s):
    """A small black icon of height s centred on (cx, cy). Drawn as shapes: the fonts have no emoji."""
    r = s / 2
    if name == 'star':
        pts = []
        for i in range(10):
            a = math.pi / 2 + i * math.pi / 5
            rr = r if i % 2 == 0 else r * 0.42
            pts.append((cx + rr * math.cos(a), cy - rr * math.sin(a)))
        d.polygon(pts, fill=0)
    elif name == 'heart':
        q = r * 0.52
        d.ellipse((cx - 2 * q, cy - r * 0.8, cx, cy - r * 0.8 + 2 * q), fill=0)
        d.ellipse((cx, cy - r * 0.8, cx + 2 * q, cy - r * 0.8 + 2 * q), fill=0)
        d.polygon([(cx - 2 * q + r * 0.03, cy - r * 0.8 + q * 1.25), (cx + 2 * q - r * 0.03, cy - r * 0.8 + q * 1.25),
                   (cx, cy + r)], fill=0)
    elif name == 'bolt':
        pts = [(0.15, -1), (-0.55, 0.12), (-0.02, 0.12), (-0.25, 1), (0.55, -0.2), (0.03, -0.2), (0.35, -1)]
        d.polygon([(cx + x * r, cy + y * r) for x, y in pts], fill=0)
    elif name == 'pokeball':
        w = max(2, round(s * 0.09))
        box = (cx - r, cy - r, cx + r, cy + r)
        d.pieslice(box, 180, 360, fill=0)                       # top half (red on a real ball)
        d.ellipse(box, outline=0, width=w)
        d.rectangle((cx - r, cy - w * 0.7, cx + r, cy + w * 0.7), fill=0)   # band
        b = r * 0.36
        d.ellipse((cx - b, cy - b, cx + b, cy + b), fill=255, outline=0, width=w)
        b2 = b * 0.45
        d.ellipse((cx - b2, cy - b2, cx + b2, cy + b2), outline=0, width=max(1, w // 2))


def _draw_qr(d, text, box):
    """Draws a QR code for `text` as large as fits in box, with whole-dot modules so it scans."""
    import qrcode   # bundled in vendor/
    q = qrcode.QRCode(border=0, error_correction=qrcode.constants.ERROR_CORRECT_M)
    q.add_data(text)
    q.make(fit=True)
    m = q.get_matrix()
    side = min(box[2] - box[0], box[3] - box[1])
    cell = max(1, int(side // len(m)))
    x0 = round(box[0] + (box[2] - box[0] - cell * len(m)) / 2)
    y0 = round(box[1] + (box[3] - box[1] - cell * len(m)) / 2)
    for y, row in enumerate(m):
        for x, dark in enumerate(row):
            if dark:
                d.rectangle((x0 + x * cell, y0 + y * cell, x0 + (x + 1) * cell - 1, y0 + (y + 1) * cell - 1), fill=0)


def _inset(r, d):
    return (r[0] + d, r[1] + d, r[2] - d, r[3] - d)


def _dashed_rect(d, r, width, dash, gap):
    x0, y0, x1, y1 = r
    for a, b, horiz, fixed in ((x0, x1, True, y0), (x0, x1, True, y1),
                               (y0, y1, False, x0), (y0, y1, False, x1)):
        p = a
        while p < b:
            q = min(p + dash, b)
            if horiz:
                d.line([(p, fixed), (q, fixed)], fill=0, width=width)
            else:
                d.line([(fixed, p), (fixed, q)], fill=0, width=width)
            p = q + gap


def _draw_border(d, style, outer, k=K):
    if style == 'double':
        # Pillow strokes inside the box; grow it by half a stroke so lines are centred on
        # the box edge, as in the approved Swift version
        w1, w2 = round(0.7 * k), max(2, round(0.25 * k))
        d.rounded_rectangle(_inset(outer, -w1 / 2), radius=2.2 * k, outline=0, width=w1)
        inner = _inset(outer, 1.1 * k)
        d.rounded_rectangle(_inset(inner, -w2 / 2), radius=1.4 * k, outline=0, width=w2)
        s = 0.9 * k
        for x in (inner[0], inner[2]):
            y = (inner[1] + inner[3]) / 2
            d.polygon([(x, y - s), (x + s, y), (x, y + s), (x - s, y)], fill=0)
    elif style == 'simple':
        d.rounded_rectangle(outer, radius=2.0 * k, outline=0, width=round(0.35 * k))
    elif style == 'bold':
        d.rounded_rectangle(outer, radius=0.8 * k, outline=0, width=round(1.0 * k))
    elif style == 'dashed':
        _dashed_rect(d, outer, round(0.4 * k), dash=2.0 * k, gap=1.2 * k)


def render(lines, border='double', layout=None, k=K, family='sans', icon='none', qr=''):
    """Returns a pure black/white 'L' image of the label at k dots/mm. First line is the bold title.
    family picks the font, icon puts a small icon each side of the title, qr adds a QR code
    of that text on the right."""
    lay = layout or Layout()
    W, H = round(lay.width * k), round(lay.height * k)
    img = Image.new('L', (W, H), 255)
    d = ImageDraw.Draw(img)
    cx, cy = W / 2 + lay.offset_x * k, H / 2 + lay.offset_y * k
    bw, bh = lay.border_w * k, lay.border_h * k
    outer = (cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2)
    _draw_border(d, border, outer, k)

    # Text area: inside the inner border line, with a little breathing room
    area = _inset(outer, 2.4 * k)
    if qr:
        # QR code fills the right of the area at full height; the text centres in what's left
        side = area[3] - area[1]
        _draw_qr(d, qr, (area[2] - side, area[1], area[2], area[3]))
        area = (area[0], area[1], area[2] - side - 1.5 * k, area[3])
        cx = (area[0] + area[2]) / 2
    aw, ah = area[2] - area[0], area[3] - area[1]
    lines = [l for l in lines if l.strip()] or [' ']
    title, rest = lines[0], lines[1:]

    # Stack: title, a thin rule, then the other lines at half the title size
    factor = 1.15 + (0.35 + 0.5 * 1.25 * len(rest) if rest else 0)
    t_size = min((80 if rest else 110) * k / K, ah / factor)
    o_size = t_size * 0.5
    y = cy - t_size * factor / 2

    # Icons each side of the title take room from it
    s = t_size * 0.72 if icon in ICONS and icon != 'none' else 0
    gap = s * 0.35
    # Icons also keep clear of the border's side diamonds
    f = _fit('bold', t_size, title, aw - 2 * (s + gap) - (2.0 * k if s else 0), family)
    for _ in range(3 if s else 0):
        # A title squeezed smaller gets smaller icons to match, which frees room for the title again
        s = min(t_size * 0.72, f.size * 0.8)
        gap = s * 0.35
        f = _fit('bold', t_size, title, aw - 2 * (s + gap) - 2.0 * k, family)
    ty = y + t_size * 1.15 / 2
    d.text((cx, ty), title, font=f, fill=0, anchor='mm')
    if s:
        tw = _ink_width(f, title)
        for side_x in (cx - tw / 2 - gap - s / 2, cx + tw / 2 + gap + s / 2):
            _draw_icon(d, icon, side_x, ty, s)
    y += t_size * 1.15
    if rest:
        rule_y = y + t_size * 0.35 / 2 - 0.3 * k
        half = min(aw / 2, max(14 * k, _ink_width(f, title) / 2 + (s + gap if s else 0)))
        d.line([(cx - half, rule_y), (cx + half, rule_y)], fill=0, width=max(2, round(0.18 * k)))
        y += t_size * 0.35
        for line in rest:
            f = _fit('regular', o_size, line, aw, family)
            d.text((cx, y + o_size * 1.25 / 2), line, font=f, fill=0, anchor='mm')
            y += o_size * 1.25

    return img.point(lambda v: 0 if v < 128 else 255)


PHOTO_MODES = {'fit': 'Fit whole photo', 'fill': 'Fill label'}
# Gamma applied before dithering: thermal prints of photos tend to come out dark
PHOTO_TONES = {'normal': ('Normal', 0.85), 'lighter': ('Lighter', 0.6), 'darker': ('Darker', 1.15)}


def render_photo(photo, border='none', mode='fit', tone='normal', layout=None, k=K):
    """A photo as a dithered black/white 'L' label image at k dots/mm, inside the same
    sticker area (and optional border) as text labels."""
    lay = layout or Layout()
    W, H = round(lay.width * k), round(lay.height * k)
    img = Image.new('L', (W, H), 255)
    cx, cy = W / 2 + lay.offset_x * k, H / 2 + lay.offset_y * k
    bw, bh = lay.border_w * k, lay.border_h * k
    outer = (cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2)
    box = outer
    if border != 'none':
        _draw_border(ImageDraw.Draw(img), border, outer, k)
        box = _inset(outer, (2.0 if border == 'double' else 1.4) * k)
    size = (int(box[2] - box[0]), int(box[3] - box[1]))

    p = ImageOps.exif_transpose(photo).convert('L')
    p = ImageOps.autocontrast(p, cutoff=1)
    gamma = PHOTO_TONES.get(tone, PHOTO_TONES['normal'])[1]
    p = p.point([round(255 * (v / 255) ** gamma) for v in range(256)])
    p = (ImageOps.fit if mode == 'fill' else ImageOps.contain)(p, size, Image.LANCZOS)
    p = p.convert('1')  # Floyd-Steinberg dithering: shades become dot patterns
    img.paste(p.convert('L'), (round(box[0] + (size[0] - p.width) / 2),
                               round(box[1] + (size[1] - p.height) / 2)))
    return img


def preview_png(img, path):
    """Label on a grey background so the white sticker shows up in Telegram."""
    pad = 24
    bg = Image.new('L', (img.width + 2 * pad, img.height + 2 * pad), 170)
    bg.paste(img, (pad, pad))
    bg.save(path, 'PNG')


def make_pdf(img, wmm, hmm):
    """One-page PDF at the exact label size holding the 8-bit gray image."""
    w, h = img.size
    pw, ph = wmm * 72 / 25.4, hmm * 72 / 25.4
    data = zlib.compress(img.tobytes())
    content = b'q %.3f 0 0 %.3f 0 0 cm /Im0 Do Q' % (pw, ph)
    objs = [
        b'<</Type/Catalog/Pages 2 0 R>>',
        b'<</Type/Pages/Kids[3 0 R]/Count 1>>',
        b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 %.3f %.3f]'
        b'/Resources<</XObject<</Im0 5 0 R>>>>/Contents 4 0 R>>' % (pw, ph),
        b'<</Length %d>>stream\n' % len(content) + content + b'\nendstream',
        b'<</Type/XObject/Subtype/Image/Width %d/Height %d/ColorSpace/DeviceGray'
        b'/BitsPerComponent 8/Filter/FlateDecode/Length %d>>stream\n' % (w, h, len(data))
        + data + b'\nendstream',
    ]
    out = b'%PDF-1.4\n'
    offsets = []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += b'%d 0 obj\n' % i + o + b'\nendobj\n'
    xref = len(out)
    out += b'xref\n0 %d\n0000000000 65535 f \n' % (len(objs) + 1)
    out += b''.join(b'%010d 00000 n \n' % off for off in offsets)
    out += b'trailer\n<</Size %d/Root 1 0 R>>\nstartxref\n%d\n%%%%EOF\n' % (len(objs) + 1, xref)
    return out


def make_cups_raster(lines, border, layout, page_size, dpi=300, margin_pt=2.0, darkness=2, draw=None, page=None):
    """The label driver's own input format (CUPS raster v3, 1 bit per dot), so CUPS only runs
    the tiny rastertolabel filter. Going via PDF made CUPS run Ghostscript, which took ~50 s
    per label on the Pi Zero. Header fields match what the Mac's driver produced for the
    WL57x32mm size (ImageableArea "2.00 0.00 159.57 90.71").

    page describes the printer's page as its driver does ({'w_pt', 'h_pt', 'area': (llx, lly,
    urx, ury), 'dpi', 'flip'}); without it the page is the layout's size with margin_pt each side.
    The page's width runs across the print head, so a label laid out the way it's read is
    turned to match."""
    if page:
        pw, ph, dpi = page['w_pt'], page['h_pt'], page.get('dpi') or dpi
        llx, lly, urx, ury = page['area']
    else:
        pw, ph = layout.width * 72 / 25.4, layout.height * 72 / 25.4
        llx, lly, urx, ury = margin_pt, 0.0, pw - margin_pt, ph
    # Whole label at printer dpi. draw(k) supplies another design (e.g. a photo) instead of text.
    img = (draw or (lambda k: render(lines, border, layout, k)))(dpi / 25.4)
    if (pw < ph) != (img.width < img.height):
        img = img.transpose(Image.Transpose.ROTATE_90)
    if page and page.get('flip'):
        img = img.transpose(Image.Transpose.ROTATE_180)
    dot = lambda pt: round(pt / 72 * dpi)
    x0, y0 = dot(llx), dot(ph - ury)          # raster rows run top-down; PPD areas bottom-up
    w, h = dot(urx) - x0, dot(ph - lly) - y0
    bpl = (w + 7) // 8
    # Rows are sent as whole bytes; pad them with white, or the spare bits at the end of
    # each row print as a thin black line down the right edge
    padded = Image.new('L', (bpl * 8, h), 255)
    padded.paste(img.crop((x0, y0, x0 + w, y0 + h)), (0, 0))
    img = padded.convert('1', dither=Image.Dither.NONE)
    # Pillow's mode '1' packs black as 0; CUPS K colorspace wants 1 = black
    data = bytes(b ^ 0xFF for b in img.tobytes())

    hdr = bytearray(1796)
    put = lambda off, fmt, *v: struct.pack_into('<' + fmt, hdr, off, *v)
    put(276, '2I', dpi, dpi)                                       # HWResolution
    put(284, '4I', int(llx), int(lly), int(urx), int(ury))         # ImagingBoundingBox
    put(312, '2I', int(llx), int(lly))                             # Margins
    put(340, 'I', 1)                                               # NumCopies
    put(352, '2I', int(pw), int(ph))                               # PageSize (points)
    put(372, '6I', w, h, 0, 1, 1, bpl)  # cupsWidth/Height, MediaType, BitsPerColor/Pixel, BytesPerLine
    put(400, '2I', 3, darkness)                                    # ColorSpace K, Compression (print density)
    put(420, 'I', 1)                                               # NumColors
    put(424, '7f', 1.0, pw, ph, llx, lly, urx, ury)                # scaling, cupsPageSize, cupsImagingBBox
    put(452, 'I', 1)                                               # cupsInteger[0]
    hdr[1732:1732 + len(page_size)] = page_size.encode()           # cupsPageSizeName
    return b'3SaR' + bytes(hdr) + data


def print_label(lines, border, printer, page_size, layout, copies=1, title='Label', draw=None,
                page=None, darkness=2):
    """Sends the label to CUPS. Returns the job id (e.g. DYMO_LabelWriter_400-12)."""
    fd, path = tempfile.mkstemp(suffix='.ras')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(make_cups_raster(lines, border, layout, page_size, draw=draw, page=page, darkness=darkness))
        r = subprocess.run(['lp', '-d', printer, '-o', 'PageSize=' + page_size,
                            '-n', str(int(copies)),
                            '-t', title[:60], path],
                           capture_output=True, text=True, timeout=30)
    finally:
        os.remove(path)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout).strip() or 'lp failed')
    m = re.search(r'request id is (\S+)', r.stdout)
    return m.group(1) if m else r.stdout.strip()


def wait_for_job(job, printer, timeout=40):
    """Waits for the job to leave the queue. Returns (done, printer status text)."""
    end = time.time() + timeout
    while time.time() < end:
        q = subprocess.run(['lpstat', '-W', 'not-completed', '-o', printer],
                           capture_output=True, text=True).stdout
        if job not in q:
            return True, ''
        time.sleep(2)
    status = subprocess.run(['lpstat', '-p', printer], capture_output=True, text=True).stdout
    return False, ' '.join(status.split())
