#!/usr/bin/env python3
"""Telegram label printer bot.

Send the bot some text (one label line per message line), tweak it with the buttons
under the preview (border, extra lines, date, copies), then tap Print.
Uses only the standard library plus Pillow, so it runs on a Pi Zero W.
"""
import base64
import datetime
import json
import os
import sys
import tempfile
import textwrap
import threading
import time
import traceback
import urllib.error
import urllib.request
import uuid

import io
import socket

from PIL import Image, ImageOps

import label
import printers

# Telegram over IPv4 only: on this network IPv6 has no internet route, and each
# failed IPv6 attempt would stall a request until it timed out
_getaddrinfo = socket.getaddrinfo
socket.getaddrinfo = lambda host, *a, **kw: [
    r for r in _getaddrinfo(host, *a, **kw) if r[0] == socket.AF_INET] or _getaddrinfo(host, *a, **kw)

HERE = os.path.dirname(os.path.abspath(__file__))
ALLOWED_FILE = os.path.join(HERE, 'allowed_users.json')
MAX_LINES, MAX_CHARS, MAX_COPIES = 6, 40, 50
GUEST_MAX_COPIES = 5   # anyone can print; this stops a stranger emptying a roll in one go
OWNER_COMMANDS = {'/card', '/deepseek', '/qr', '/printer', '/align'}


def load_config():
    cfg = {}
    with open(os.path.join(HERE, 'config.env')) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, v = line.split('=', 1)
                cfg[k.strip()] = v.strip()
    return cfg


CFG = load_config()
API = 'https://api.telegram.org/bot%s/' % CFG['BOT_TOKEN']
PRINTER = CFG.get('PRINTER', 'DYMO_LabelWriter_400')
PAGE_SIZE = CFG.get('PAGE_SIZE', 'WL57x32mm')
DATE_FORMAT = CFG.get('DATE_FORMAT', '%d/%m/%Y')
LAYOUT = label.Layout(CFG)


def log(*a):
    print(time.strftime('%Y-%m-%d %H:%M:%S'), *a, flush=True)


# ---------- Telegram API ----------

class ApiError(Exception):
    pass


def _multipart(fields, files):
    boundary = uuid.uuid4().hex
    out = b''
    for k, v in fields.items():
        if not isinstance(v, str):
            v = json.dumps(v)
        out += ('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n%s\r\n'
                % (boundary, k, v)).encode()
    for k, (name, data) in files.items():
        out += ('--%s\r\nContent-Disposition: form-data; name="%s"; filename="%s"\r\n'
                'Content-Type: image/png\r\n\r\n' % (boundary, k, name)).encode() + data + b'\r\n'
    out += ('--%s--\r\n' % boundary).encode()
    return out, 'multipart/form-data; boundary=' + boundary


def api(method, params=None, files=None, timeout=70):
    if files:
        body, ctype = _multipart(params or {}, files)
    else:
        body, ctype = json.dumps(params or {}).encode(), 'application/json'
    req = urllib.request.Request(API + method, data=body, headers={'Content-Type': ctype})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            res = json.load(r)
    except urllib.error.HTTPError as e:
        res = json.load(e)
    if not res.get('ok'):
        raise ApiError(res.get('description', 'unknown error'))
    return res['result']


def send(chat, text, **kw):
    return api('sendMessage', dict(chat_id=chat, text=text, **kw))


def download(file_id):
    path = api('getFile', {'file_id': file_id})['file_path']
    url = 'https://api.telegram.org/file/bot%s/%s' % (CFG['BOT_TOKEN'], path)
    with urllib.request.urlopen(url, timeout=60) as r:
        return r.read()


# ---------- Who may use the bot ----------

def load_allowed():
    ids = {int(x) for x in CFG.get('ALLOWED_USER_IDS', '').replace(' ', '').split(',') if x}
    try:
        with open(ALLOWED_FILE) as f:
            ids |= set(json.load(f))
    except FileNotFoundError:
        pass
    return ids


def save_allowed(ids):
    with open(ALLOWED_FILE, 'w') as f:
        json.dump(sorted(ids), f)


ALLOWED = load_allowed()


# ---------- Label drafts (one per chat) ----------

DRAFTS = {}   # chat_id -> {'lines', 'border', 'copies', 'msg_id', 'awaiting', 'status'}
LOCK = threading.Lock()


# ---------- Settings that survive restarts (alignment, last border) ----------

SETTINGS_FILE = os.path.join(HERE, 'settings.json')
DARKNESS = ['Light', 'Medium', 'Normal', 'Dark']   # the label driver's density levels 0-3
DEFAULTS = {'offset_x': LAYOUT.offset_x, 'offset_y': LAYOUT.offset_y, 'border': 'double',
            'font': 'sans', 'icon': 'none', 'qr_link': '', 'darkness': 'Normal', 'flip': False}
MAX_QR = 150   # longer links make the QR dots too small to scan on a 32 mm label
STEP_MM, MAX_OFFSET_MM = 0.5, 5.0


def load_settings():
    st = dict(DEFAULTS)
    try:
        with open(SETTINGS_FILE) as f:
            st.update(json.load(f))
    except (FileNotFoundError, ValueError):
        pass
    if st['border'] not in label.BORDERS:
        st['border'] = 'double'
    if st['font'] not in label.FONTS:
        st['font'] = 'sans'
    if st['icon'] not in label.ICONS:
        st['icon'] = 'none'
    if st['darkness'] not in DARKNESS:
        st['darkness'] = 'Normal'
    return st


def save_settings():
    tmp = SETTINGS_FILE + '.tmp'
    with open(tmp, 'w') as f:
        os.chmod(tmp, 0o600)   # holds the DeepSeek API key
        json.dump(SETTINGS, f, indent=1)
    os.replace(tmp, SETTINGS_FILE)


SETTINGS = load_settings()


# ---------- Printer, label size and darkness (changed from Telegram with /printer) ----------

PAGE = None   # the current label size as the printer's driver describes it (see printers.sizes)


def base_offsets(printer, size):
    """What alignment Reset goes back to: the values tuned on paper for the original printer
    and size (config.env), otherwise centred."""
    if (printer, size) == (CFG.get('PRINTER', 'DYMO_LabelWriter_400'), CFG.get('PAGE_SIZE', 'WL57x32mm')):
        return DEFAULTS['offset_x'], DEFAULTS['offset_y']
    return 0.0, 0.0


def apply_printer():
    """Points printing at the saved printer and label size, and sizes the layout to match."""
    global PRINTER, PAGE_SIZE, PAGE
    PRINTER = SETTINGS.get('printer') or CFG.get('PRINTER', 'DYMO_LabelWriter_400')
    PAGE_SIZE = SETTINGS.get('page_size') or CFG.get('PAGE_SIZE', 'WL57x32mm')
    try:
        PAGE = printers.find_size(PRINTER, PAGE_SIZE)
    except Exception as e:   # e.g. CUPS not started yet; config.env's size is used meanwhile
        log('could not read the printer\'s label sizes:', e)
        PAGE = None
    if PAGE:
        LAYOUT.width, LAYOUT.height = printers.size_mm(PAGE)
        # Border: 2.5 mm in (less on small labels), and inside what the printer can actually
        # print: many sizes lose ~5 mm at each end of the feed
        llx, lly, urx, ury = PAGE['area']
        across, along = (urx - llx) * 25.4 / 72, (ury - lly) * 25.4 / 72
        long_pr, short_pr = (across, along) if PAGE['w_pt'] >= PAGE['h_pt'] else (along, across)
        m = min(2.5, LAYOUT.height * 0.08)
        LAYOUT.border_w = min(LAYOUT.width - 2 * m, long_pr - 1.0)
        LAYOUT.border_h = min(LAYOUT.height - 2 * m, short_pr - 1.0)
    LAYOUT.offset_x, LAYOUT.offset_y = SETTINGS['offset_x'], SETTINGS['offset_y']


def switch_printer(printer=None, size=None):
    """Changes printer and/or label size. Each printer + size keeps its own alignment."""
    profiles = SETTINGS.setdefault('profiles', {})
    profiles['%s|%s' % (PRINTER, PAGE_SIZE)] = {'offset_x': SETTINGS['offset_x'], 'offset_y': SETTINGS['offset_y']}
    if printer:
        SETTINGS['printer'] = printer
        SETTINGS['page_size'] = size or printers.sizes(printer)[1]
    elif size:
        SETTINGS['page_size'] = size
    p, z = SETTINGS.get('printer') or PRINTER, SETTINGS.get('page_size') or PAGE_SIZE
    bx, by = base_offsets(p, z)
    saved = profiles.get('%s|%s' % (p, z), {'offset_x': bx, 'offset_y': by})
    SETTINGS['offset_x'], SETTINGS['offset_y'] = saved['offset_x'], saved['offset_y']
    save_settings()
    apply_printer()
    log('printer now', PRINTER, PAGE_SIZE, 'alignment', SETTINGS['offset_x'], SETTINGS['offset_y'])


def page_opts():
    return dict(PAGE, flip=SETTINGS['flip']) if PAGE else None


def size_name():
    return printers.size_text(PAGE) if PAGE else '%g x %g mm' % (LAYOUT.width, LAYOUT.height)


def printer_text(note=''):
    x, y = SETTINGS['offset_x'], SETTINGS['offset_y']
    h = 'centred' if not x else '%g mm %s' % (abs(x), 'left' if x < 0 else 'right')
    v = 'centred' if not y else '%g mm %s' % (abs(y), 'up' if y < 0 else 'down')
    text = ('🖨 Printer settings\n\nPrinter: %s\nLabel: %s\nDarkness: %s · Upside down: %s\n'
            'Alignment for this printer and label: across %s, up/down %s'
            % (PRINTER, size_name(), SETTINGS['darkness'], 'Yes' if SETTINGS['flip'] else 'No', h, v))
    return text + ('\n\n' + note if note else '')


def printer_keyboard():
    b = lambda text, data: {'text': text, 'callback_data': data}
    return {'inline_keyboard': [
        [b('🖨 Printer: %s' % PRINTER[:30], 'pr:printers')],
        [b('📏 Label size: %s' % size_name()[:40], 'pr:sizes')],
        [b('🌗 Darkness: %s' % SETTINGS['darkness'], 'pr:dark'),
         b('🔄 Upside down: %s' % ('Yes' if SETTINGS['flip'] else 'No'), 'pr:flip')],
        [b('🧪 Test print', 'pr:test'), b('📐 Alignment', 'align')],
        [b('✅ Done', 'pr:done')],
    ]}


PICK = {}   # chat -> the printers / sizes / USB devices last listed, so buttons can refer to them by number


def on_printer(cq, data, answer):
    chat, msg_id = cq['message']['chat']['id'], cq['message']['message_id']
    b = lambda text, d: {'text': text, 'callback_data': d}

    def show(text, kb=None):
        p = {'chat_id': chat, 'message_id': msg_id, 'text': text}
        if kb:
            p['reply_markup'] = kb
        try:
            api('editMessageText', p)
        except ApiError as e:
            if 'not modified' not in str(e):
                raise

    def picked(kind):
        n = int(data.rsplit(':', 1)[1])
        items = PICK.get(chat, {}).get(kind, [])
        return items[n] if n < len(items) else None

    if data == 'pr:menu':
        answer()
        return show(printer_text(), printer_keyboard())
    if data == 'pr:done':
        answer('Saved')
        return show(printer_text())
    if data == 'pr:printers':
        answer()
        qs = printers.queues()
        PICK.setdefault(chat, {})['printers'] = qs
        rows = [[b(('✅ ' if q == PRINTER else '') + q, 'pr:use:%d' % i)] for i, q in enumerate(qs)]
        rows += [[b('🔍 Find a new USB printer', 'pr:scan')], [b('⬅️ Back', 'pr:menu')]]
        return show('Which printer should labels go to?' if qs else 'No printers are set up yet.',
                    {'inline_keyboard': rows})
    if data.startswith('pr:use:'):
        q = picked('printers')
        if not q:
            return answer('That list is out of date. Open /printer again.')
        answer('Using %s' % q)
        switch_printer(printer=q)
        return show(printer_text('Now using %s. Check the label size, then do a test print.' % q), printer_keyboard())
    if data == 'pr:sizes':
        answer()
        zs = printers.sizes(PRINTER)[0]
        PICK.setdefault(chat, {})['sizes'] = zs
        rows = [[b(('✅ ' if z['name'] == PAGE_SIZE else '') + printers.size_text(z), 'pr:size:%d' % i)]
                for i, z in enumerate(zs)]
        rows.append([b('⬅️ Back', 'pr:menu')])
        return show('Which labels are loaded in %s?\nSizes are as you read the label, long side across.' % PRINTER,
                    {'inline_keyboard': rows})
    if data.startswith('pr:size:'):
        z = picked('sizes')
        if not z:
            return answer('That list is out of date. Open /printer again.')
        answer()
        switch_printer(size=z['name'])
        return show(printer_text('Label size set. Do a test print to check it lines up; use 📐 Alignment '
                                 'to nudge it. This printer and size keep their own alignment.'), printer_keyboard())
    if data == 'pr:dark':
        SETTINGS['darkness'] = DARKNESS[(DARKNESS.index(SETTINGS['darkness']) + 1) % len(DARKNESS)]
        save_settings()
        answer()
        return show(printer_text(), printer_keyboard())
    if data == 'pr:flip':
        SETTINGS['flip'] = not SETTINGS['flip']
        save_settings()
        answer()
        return show(printer_text(), printer_keyboard())
    if data == 'pr:test':
        answer('Printing a test label…')
        threading.Thread(target=print_job, daemon=True,
                         args=(chat, None, ['TEST PRINT', size_name(), PRINTER], 'double', 1)).start()
        return
    if data == 'pr:scan':
        answer()
        show('🔍 Looking for USB printers… (this can take up to a minute)')
        threading.Thread(target=scan_job, args=(chat, show), daemon=True).start()
        return
    if data.startswith('pr:add:'):
        dev = picked('usb')
        if not dev:
            return answer('That list is out of date. Open /printer again.')
        answer()
        show('⚙️ Setting up %s…' % (dev.get('make-and-model') or 'the printer'))
        threading.Thread(target=add_job, args=(dev, show), daemon=True).start()
        return
    answer()


def scan_job(chat, show):
    b = lambda text, d: {'text': text, 'callback_data': d}
    try:
        devs = printers.usb_devices()
    except Exception as e:
        return show('❌ Couldn\'t look for printers: %s' % e, {'inline_keyboard': [[b('⬅️ Back', 'pr:menu')]]})
    PICK.setdefault(chat, {})['usb'] = devs
    rows = [[b('➕ ' + (d.get('make-and-model') or d['uri'])[:50], 'pr:add:%d' % i)] for i, d in enumerate(devs)]
    rows += [[b('🔍 Scan again', 'pr:scan')], [b('⬅️ Back', 'pr:menu')]]
    show('Tap the printer to set it up:' if devs else
         'No new USB printers found. Plug it into the Pi (through the USB adapter), switch it on, '
         'wait a few seconds and scan again.', {'inline_keyboard': rows})


def add_job(dev, show):
    try:
        name = printers.add_printer(dev)
    except Exception as e:
        log('add printer failed:', e)
        return show('❌ Couldn\'t set it up: %s' % e, {'inline_keyboard': [[
            {'text': '⬅️ Back', 'callback_data': 'pr:menu'}]]})
    log('added printer', name, dev['uri'])
    with LOCK:
        switch_printer(printer=name)
    show(printer_text('✅ Added %s and switched to it. Pick the label size, then do a test print.' % name),
         printer_keyboard())


apply_printer()


def align_text():
    x, y = SETTINGS['offset_x'], SETTINGS['offset_y']
    h = 'centred' if not x else '%g mm %s' % (abs(x), 'left' if x < 0 else 'right')
    v = 'centred' if not y else '%g mm %s' % (abs(y), 'up' if y < 0 else 'down')
    return ('📐 Alignment (saved, used for every print)\n'
            'Across: %s · Up/down: %s\n'
            'Each tap moves the design %g mm on the sticker.' % (h, v, STEP_MM))


def align_keyboard():
    b = lambda text, data: {'text': text, 'callback_data': data}
    return {'inline_keyboard': [
        [b('⬆️ Up', 'al:up')],
        [b('⬅️ Left', 'al:left'), b('➡️ Right', 'al:right')],
        [b('⬇️ Down', 'al:down')],
        [b('🖨 Test print', 'al:test'), b('↩️ Reset', 'al:reset')],
        [b('✅ Done', 'al:done')],
    ]}


def on_align(cq, data, answer):
    chat, msg_id = cq['message']['chat']['id'], cq['message']['message_id']
    move = {'al:up': ('offset_y', -1), 'al:down': ('offset_y', 1),
            'al:left': ('offset_x', -1), 'al:right': ('offset_x', 1)}
    if data in move:
        key, sign = move[data]
        SETTINGS[key] = round(max(-MAX_OFFSET_MM, min(MAX_OFFSET_MM, SETTINGS[key] + sign * STEP_MM)), 2)
    elif data == 'al:reset':
        SETTINGS['offset_x'], SETTINGS['offset_y'] = base_offsets(PRINTER, PAGE_SIZE)
    elif data == 'al:test':
        answer('Printing a test label…')
        threading.Thread(target=print_job, daemon=True,
                         args=(chat, None, ['ALIGNMENT TEST', align_text().split('\n')[1]], 'double', 1)).start()
        return
    elif data == 'al:done':
        answer('Saved')
        api('editMessageText', {'chat_id': chat, 'message_id': msg_id,
                                'text': align_text().split('\n')[0] + '\n' + align_text().split('\n')[1]})
        return
    LAYOUT.offset_x, LAYOUT.offset_y = SETTINGS['offset_x'], SETTINGS['offset_y']
    save_settings()
    log('alignment now', SETTINGS['offset_x'], SETTINGS['offset_y'])
    answer()
    try:
        api('editMessageText', {'chat_id': chat, 'message_id': msg_id, 'text': align_text(),
                                'reply_markup': align_keyboard()})
    except ApiError as e:
        if 'not modified' not in str(e):
            raise


def clean_lines(text):
    return [l.strip()[:MAX_CHARS] for l in text.splitlines() if l.strip()]


def wrap_lines(text, width=34):
    """Like clean_lines, but long lines (chat messages, item names) wrap onto the next line
    instead of being cut off. The first line, the title, stays one line. Ends with … if it
    still doesn't fit the label."""
    out = []
    # The label fonts have no emoji or flags (e.g. Whatnot listing titles like "🇰🇷 ⭕KRN …"):
    # drop them rather than print empty boxes
    keep = lambda c: ord(c) < 0x2000 or c in '€…–—‘’“”•'
    text = '\n'.join(' '.join(''.join(c for c in l if keep(c)).split()) for l in text.splitlines())
    for n, l in enumerate(l.strip() for l in text.splitlines() if l.strip()):
        out += [l[:MAX_CHARS]] if n == 0 else textwrap.wrap(l, width)
    if len(out) > MAX_LINES:
        out = out[:MAX_LINES]
        out[-1] = out[-1][:width - 1].rstrip() + '…'
    return out


def text_draft(chat, lines, status=''):
    """A new text label for this chat, in the last-used border, font and icon."""
    return {'lines': lines[:MAX_LINES], 'border': SETTINGS['border'], 'font': SETTINGS['font'],
            'icon': SETTINGS['icon'], 'qr': '', 'copies': 1,
            'msg_id': (DRAFTS.get(chat) or {}).get('msg_id'), 'awaiting': None, 'status': status}


def draw_for(dr):
    """The label design as a function of dots/mm, so preview and print use the same drawing."""
    if dr.get('photo'):
        p, b, m, t = dr['photo'], dr['border'], dr['mode'], dr['tone']
        return lambda k: label.render_photo(p, b, m, t, LAYOUT, k)
    lines, b, f, i, q = list(dr['lines']), dr['border'], dr.get('font', 'sans'), dr.get('icon', 'none'), dr.get('qr', '')
    return lambda k: label.render(lines, b, LAYOUT, k, f, i, q)


def caption(dr):
    c = 'Border: %s · Copies: %d' % (label.BORDER_NAMES[dr['border']], dr['copies'])
    if dr.get('photo'):
        c = '%s · %s · %s' % (label.PHOTO_MODES[dr['mode']], label.PHOTO_TONES[dr['tone']][0], c)
    elif dr.get('qr'):
        c += '\nQR: ' + dr['qr']
    return c + ('\n' + dr['status'] if dr.get('status') else '')


def keyboard(dr):
    b = lambda text, data: {'text': text, 'callback_data': data}
    if dr.get('photo'):
        return {'inline_keyboard': [
            [b('🔲 %s' % label.PHOTO_MODES['fill' if dr['mode'] == 'fit' else 'fit'], 'mode')],
            [b('🖼 Border: %s' % label.BORDER_NAMES[dr['border']], 'border'),
             b('☀️ %s' % label.PHOTO_TONES[dr['tone']][0], 'tone')],
            [b('−', 'copies-'), b('Copies: %d' % dr['copies'], 'noop'), b('+', 'copies+')],
            [b('🖨 Print', 'print'), b('✖ Cancel', 'cancel')],
        ] + ([] if dr.get('guest') else [[b('📐 Alignment', 'align')]])}
    return {'inline_keyboard': [
        [b('🖼 Border: %s' % label.BORDER_NAMES[dr['border']], 'border'),
         b('🔤 Font: %s' % label.FONTS[dr.get('font', 'sans')][0], 'font')],
        [b('✨ Icon: %s' % label.ICONS[dr.get('icon', 'none')], 'icon')] +
        ([] if dr.get('guest') else [b('🔳 QR code: %s' % ('On' if dr.get('qr') else 'Off'), 'qr')]),
        [b('➕ Add line', 'add'), b('➖ Remove last line', 'del')],
        [b('📅 Add date', 'date')],
        [b('−', 'copies-'), b('Copies: %d' % dr['copies'], 'noop'), b('+', 'copies+')],
        [b('🖨 Print', 'print'), b('✖ Cancel', 'cancel')],
    ] + ([] if dr.get('guest') else [[b('📐 Alignment', 'align')]])}


def render_png(dr):
    img = draw_for(dr)(label.K)
    fd, path = tempfile.mkstemp(suffix='.png')
    os.close(fd)
    try:
        label.preview_png(img, path)
        with open(path, 'rb') as f:
            return img, f.read()
    finally:
        os.remove(path)


def send_preview(chat, dr):
    """Posts a fresh preview (and strips the buttons off the previous one)."""
    if dr.get('msg_id'):
        try:
            api('editMessageReplyMarkup', {'chat_id': chat, 'message_id': dr['msg_id'],
                                           'reply_markup': {'inline_keyboard': []}})
        except ApiError:
            pass
    _, png = render_png(dr)
    msg = api('sendPhoto', {'chat_id': chat, 'caption': caption(dr),
                            'reply_markup': keyboard(dr)},
              files={'photo': ('label.png', png)})
    dr['msg_id'] = msg['message_id']


def update_preview(chat, dr, image=True):
    try:
        if image:
            _, png = render_png(dr)
            api('editMessageMedia', {
                'chat_id': chat, 'message_id': dr['msg_id'],
                'media': {'type': 'photo', 'media': 'attach://photo', 'caption': caption(dr)},
                'reply_markup': keyboard(dr)}, files={'photo': ('label.png', png)})
        else:
            api('editMessageCaption', {'chat_id': chat, 'message_id': dr['msg_id'],
                                       'caption': caption(dr), 'reply_markup': keyboard(dr)})
    except ApiError as e:
        if 'not modified' not in str(e):
            raise


HELP = ('Send me the text for a label, one line per line, e.g.\n\n'
        'RJ POKESHOP NEATH\n£23\n\n'
        'The first line is the big bold title. Then use the buttons to pick a border, '
        'add lines or today\'s date, set copies and print. 🔤 Font and ✨ Icon change the style '
        '(your last choice is remembered), and 🔳 QR code adds a QR code of your link: /qr sets it.\n\n'
        'Or send a photo to print it in black and white: choose whether it fits whole or '
        'fills the label, add a border, or make it lighter or darker.\n\n'
        '/card, then a photo of a Pokémon card in any language, makes an info label with its '
        'English name, set, number and rarity. It needs a DeepSeek API key: /deepseek YOUR_KEY\n\n'
        '/printer switches printer or label size, or sets darkness, when you change rolls or printers.\n\n'
        '/align moves the design on the sticker if prints come out off-centre. '
        'Alignment and your last border are remembered.')

HELP_GUEST = ('Send me the text for a label, one line per line, e.g.\n\n'
              'Kait\nThank you!\n\n'
              'The first line is the big bold title. Then use the buttons to pick a border, font or icon, '
              'add lines or today\'s date, set copies (up to %d) and tap Print.\n\n'
              'Or send a photo to print it in black and white.' % GUEST_MAX_COPIES)


# ---------- Pokémon card lookup (DeepSeek vision) ----------

DEEPSEEK_URL = 'https://api.deepseek.com/'
CARD_WAIT = set()   # chats whose next photo is a card to look up

CARD_PROMPT = (
    'You identify Pokémon Trading Card Game cards from photos. Cards may be in Japanese, Korean, '
    'Chinese (traditional or simplified), Thai, Indonesian or another language. '
    'Reply with JSON only, using exactly these keys:\n'
    '{"is_pokemon_card": true/false, "english_name": "official English card name, e.g. Pikachu ex", '
    '"original_name": "name as printed", "language": "language of the card", '
    '"set_name": "official English name of the set; for a region-only set give its usual English '
    'translation", "set_code": "set code if known, e.g. sv4a", "card_number": "as printed, e.g. 236/190", '
    '"rarity_code": "short rarity as printed or used by collectors, e.g. SAR, AR, RR, C", '
    '"rarity": "what that rarity means", "card_type": "Pokémon / Trainer / Energy, with stage", '
    '"hp": "", "pokemon_type": "e.g. Lightning", '
    '"english_equivalent": "English-release set and number with the same card, if one exists", '
    '"confidence": "high, medium or low", "notes": "anything useful, e.g. promo, 1st edition, '
    'region-exclusive, or what you could not read"}\n'
    'Use "" for anything you cannot read or do not know. Never invent a card number you cannot see.')


def deepseek(path, body=None, timeout=120):
    req = urllib.request.Request(DEEPSEEK_URL + path, data=json.dumps(body).encode() if body else None,
                                 headers={'Content-Type': 'application/json',
                                          'Authorization': 'Bearer ' + SETTINGS.get('deepseek_key', '')})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        try:
            msg = json.load(e).get('error', {}).get('message', '')
        except ValueError:
            msg = ''
        raise RuntimeError('DeepSeek said: %s' % (msg or 'HTTP %d' % e.code))


def identify_card(jpeg):
    res = deepseek('chat/completions', {
        'model': CFG.get('DEEPSEEK_MODEL', 'deepseek-flash'),
        # The model thinks before answering and that counts towards max_tokens, so leave plenty of
        # room (unused tokens cost nothing; 6000 at most is well under 1p)
        'temperature': 0, 'max_tokens': 6000, 'response_format': {'type': 'json_object'},
        'messages': [
            {'role': 'system', 'content': CARD_PROMPT},
            {'role': 'user', 'content': [
                {'type': 'text', 'text': 'Identify this Pokémon card. Reply in JSON.'},
                {'type': 'image_url', 'image_url': {
                    'url': 'data:image/jpeg;base64,' + base64.b64encode(jpeg).decode(), 'detail': 'high'}}]}]})
    choice = res['choices'][0]
    content = (choice['message'].get('content') or '').strip()
    log('deepseek finish=%s usage=%s' % (choice.get('finish_reason'), res.get('usage', {}).get('completion_tokens')))
    if not content:
        raise RuntimeError('DeepSeek gave an empty answer (%s). Try again.' % (
            'it ran out of room while thinking' if choice.get('finish_reason') == 'length'
            else 'finish reason: %s' % choice.get('finish_reason')))
    # Tolerate the JSON arriving wrapped in ```json fences or a sentence
    start, end = content.find('{'), content.rfind('}')
    try:
        return json.loads(content[start:end + 1] if start >= 0 else content)
    except ValueError:
        log('deepseek non-JSON answer:', content[:500])
        raise RuntimeError('DeepSeek\'s answer wasn\'t in the expected format. Try again.')


def latin(s):
    """The label font has no Japanese/Chinese/Korean glyphs; keep what it can print."""
    return ' '.join(''.join(c for c in str(s or '') if ord(c) < 0x250).split())


def card_lines(info):
    g = lambda k: latin(info.get(k))
    set_line = g('set_name') + (' (%s)' % g('set_code') if g('set_code') else '')
    num = ' · '.join(x for x in ('#' + g('card_number') if g('card_number') else '', g('rarity_code')) if x)
    lines = [g('english_name'), set_line, num, g('language')]
    if g('english_equivalent'):
        lines.append('EN: ' + g('english_equivalent'))
    return clean_lines('\n'.join(l for l in lines if l))[:MAX_LINES]


def card_text(info):
    rows = [('Name', 'english_name'), ('Printed name', 'original_name'), ('Language', 'language'),
            ('Set', 'set_name'), ('Set code', 'set_code'), ('Number', 'card_number'),
            ('Rarity', 'rarity_code'), ('Rarity meaning', 'rarity'), ('Card type', 'card_type'),
            ('HP', 'hp'), ('Type', 'pokemon_type'), ('English release', 'english_equivalent'),
            ('Confidence', 'confidence'), ('Notes', 'notes')]
    out = ['🃏 %s: %s' % (n, info[k]) if n == 'Name' else '%s: %s' % (n, info[k])
           for n, k in rows if str(info.get(k) or '').strip()]
    return '\n'.join(out) + '\n\nCheck the details before printing: AI can misread cards. The label is below.'


SCAN_AGAIN = {'inline_keyboard': [[{'text': '📷 Scan another card', 'callback_data': 'card'}]]}


def card_lookup(chat, file_id):
    status = send(chat, '🔎 Looking up the card…')

    def say(text, markup=None):
        p = {'chat_id': chat, 'message_id': status['message_id'], 'text': text[:4000]}
        if markup:
            p['reply_markup'] = markup
        api('editMessageText', p)
    try:
        img = ImageOps.exif_transpose(Image.open(io.BytesIO(download(file_id)))).convert('RGB')
        img.thumbnail((1600, 1600))
        buf = io.BytesIO()
        img.save(buf, 'JPEG', quality=90)
        info = identify_card(buf.getvalue())
        log('card', info.get('english_name'), info.get('set_name'), info.get('card_number'))
    except Exception as e:
        log('card lookup failed:', e)
        return say('❌ Card lookup failed: %s' % e, SCAN_AGAIN)
    if not info.get('is_pokemon_card', True) or not card_lines(info):
        return say('🤔 I couldn\'t recognise a Pokémon card in that photo. Try again with the card flat, '
                   'filling the picture, in good light and without glare.', SCAN_AGAIN)
    say(card_text(info), SCAN_AGAIN)
    with LOCK:
        dr = DRAFTS[chat] = text_draft(chat, card_lines(info))
        send_preview(chat, dr)


def set_deepseek_key(chat, msg, arg):
    if arg.lower() in ('off', 'remove', 'delete'):
        SETTINGS.pop('deepseek_key', None)
        save_settings()
        return send(chat, 'DeepSeek key removed. /card won\'t work until you add one again.')
    if not arg:
        key = SETTINGS.get('deepseek_key')
        return send(chat, ('DeepSeek key is set (ends …%s).' % key[-4:] if key else 'No DeepSeek key set yet.') +
                    '\n\nTo set it: /deepseek YOUR_API_KEY\nTo remove it: /deepseek off\n'
                    'Get a key at platform.deepseek.com → API keys.')
    try:   # keep the key out of the chat history
        api('deleteMessage', {'chat_id': chat, 'message_id': msg['message_id']})
    except ApiError:
        pass
    old = SETTINGS.get('deepseek_key')
    SETTINGS['deepseek_key'] = arg
    try:
        deepseek('models', timeout=20)
    except Exception as e:
        if old:
            SETTINGS['deepseek_key'] = old
        else:
            SETTINGS.pop('deepseek_key')
        return send(chat, '❌ That key didn\'t work, so I didn\'t save it. %s' % e)
    save_settings()
    send(chat, '✅ DeepSeek key saved (ends …%s). I deleted your message so the key isn\'t left in the chat.\n\n'
               'Send /card, then a photo of a card.' % arg[-4:])


def image_file_id(msg):
    """The best-quality image in a message: a photo, or an image sent as a file."""
    if msg.get('photo'):
        return msg['photo'][-1]['file_id']   # sizes come smallest first
    doc = msg.get('document') or {}
    if doc.get('mime_type', '').startswith('image/'):
        return doc['file_id']
    return None


def on_message(msg):
    chat, user = msg['chat']['id'], msg.get('from', {}).get('id')
    text = msg.get('text', '')
    global ALLOWED
    if not ALLOWED and text.startswith('/start'):
        ALLOWED = {user}
        save_allowed(ALLOWED)
        log('owner claimed by user', user)
        send(chat, 'You\'re now the owner of this printer bot. Others can print labels, '
                   'but only you can change its settings.\n\n' + HELP)
        return
    owner = user in ALLOWED
    if not owner:
        who = msg.get('from', {})
        log('guest', user, who.get('username') or who.get('first_name'), repr(text[:60]) if text else '(photo)')
    image_id = image_file_id(msg)
    if image_id and not owner and msg.get('caption', '').startswith('/card'):
        return send(chat, 'Sorry, card scanning is only for the bot\'s owner. You can still print the photo: '
                          'send it without /card.')
    if image_id and owner and (chat in CARD_WAIT or msg.get('caption', '').startswith('/card')):
        CARD_WAIT.discard(chat)
        if not SETTINGS.get('deepseek_key'):
            return send(chat, 'Card scanning needs a DeepSeek API key first: /deepseek YOUR_API_KEY')
        # A lookup takes a while; don't hold up other messages
        threading.Thread(target=card_lookup, args=(chat, image_id), daemon=True).start()
        return
    if image_id:
        try:
            photo = ImageOps.exif_transpose(Image.open(io.BytesIO(download(image_id))))
            photo.thumbnail((1600, 1600))   # plenty for a label; keeps the Pi Zero's memory free
        except Exception as e:
            log('photo failed:', e)
            send(chat, 'Sorry, I couldn\'t open that image.')
            return
        dr = {'photo': photo, 'lines': ['Photo'], 'border': 'none', 'mode': 'fit', 'tone': 'normal',
              'copies': 1, 'msg_id': (DRAFTS.get(chat) or {}).get('msg_id'), 'awaiting': None, 'status': '',
              'guest': not owner}
        DRAFTS[chat] = dr
        send_preview(chat, dr)
        return
    if not text:
        send(chat, 'Send me text or a photo for the label.')
        return
    if text.startswith('/'):
        cmd = text.split()[0].split('@')[0]
        if not owner and cmd in OWNER_COMMANDS:
            send(chat, 'Sorry, only the bot\'s owner can use %s. You can send text or a photo to print a label.' % cmd)
        elif not owner and cmd != '/cancel':
            send(chat, HELP_GUEST)
        elif cmd == '/cancel':
            DRAFTS.pop(chat, None)
            CARD_WAIT.discard(chat)
            send(chat, 'Cancelled.')
        elif cmd == '/card':
            if not SETTINGS.get('deepseek_key'):
                send(chat, 'Card scanning needs a DeepSeek API key first: /deepseek YOUR_API_KEY')
            else:
                CARD_WAIT.add(chat)
                send(chat, '📷 Send a photo of the card: front side, flat, filling the picture, no glare.')
        elif cmd == '/deepseek':
            set_deepseek_key(chat, msg, text.split(None, 1)[1].strip() if len(text.split(None, 1)) > 1 else '')
        elif cmd == '/qr':
            arg = text.split(None, 1)[1].strip() if len(text.split(None, 1)) > 1 else ''
            if arg.lower() in ('off', 'remove', 'delete'):
                SETTINGS['qr_link'] = ''
                save_settings()
                send(chat, 'Saved QR link removed.')
            elif arg:
                set_qr(chat, arg)
            else:
                send(chat, ('QR link: %s' % SETTINGS['qr_link'] if SETTINGS['qr_link'] else 'No QR link saved yet.') +
                     '\n\nTo set it: /qr https://your-link\nThen tap 🔳 QR code under a label to add it.')
        elif cmd == '/printer':
            send(chat, printer_text(), reply_markup=printer_keyboard())
        elif cmd == '/align':
            send(chat, align_text(), reply_markup=align_keyboard())
        else:
            send(chat, HELP)
        return

    dr = DRAFTS.get(chat)
    new_lines = clean_lines(text)
    if dr and dr.get('awaiting') == 'qr':
        dr['awaiting'] = None
        set_qr(chat, text.strip())
        return
    if dr and dr.get('awaiting') == 'add':
        dr['awaiting'] = None
        room = MAX_LINES - len(dr['lines'])
        dr['lines'] += new_lines[:room]
        dr['status'] = '' if len(new_lines) <= room else '⚠️ Max %d lines' % MAX_LINES
        send_preview(chat, dr)
        return
    dr = DRAFTS[chat] = text_draft(
        chat, new_lines, '' if len(new_lines) <= MAX_LINES else '⚠️ Only the first %d lines are used' % MAX_LINES)
    dr['guest'] = not owner
    send_preview(chat, dr)


def set_qr(chat, link):
    """Saves the QR link and puts it on the label being edited, if there is one."""
    if len(link) > MAX_QR:
        return send(chat, 'That\'s too long for a QR code on this label (%d characters, max %d). '
                          'Try a shorter link.' % (len(link), MAX_QR))
    SETTINGS['qr_link'] = link
    save_settings()
    dr = DRAFTS.get(chat)
    if dr and not dr.get('photo'):
        dr['qr'] = link
        dr['status'] = ''
        send_preview(chat, dr)
    else:
        send(chat, '✅ QR link saved. Tap 🔳 QR code under a label to add it.')


def on_callback(cq):
    chat = cq['message']['chat']['id']
    data = cq.get('data', '')

    def answer(text=''):
        # A tap answered late (e.g. while the Pi was busy) is rejected by Telegram; that's harmless
        try:
            api('answerCallbackQuery', {'callback_query_id': cq['id'], 'text': text})
        except ApiError as e:
            log('callback answer failed:', e)
    owner = cq['from']['id'] in ALLOWED
    if not owner and (data.startswith(('al:', 'pr:')) or data in ('align', 'card', 'qr')):
        return answer('Only the bot\'s owner can change that')
    if data.startswith('al:'):
        return on_align(cq, data, answer)
    if data.startswith('pr:'):
        return on_printer(cq, data, answer)
    if data == 'align':
        answer()
        return send(chat, align_text(), reply_markup=align_keyboard())
    if data == 'card':
        CARD_WAIT.add(chat)
        answer('Send the next card photo')
        return send(chat, '📷 Send a photo of the next card.')
    dr = DRAFTS.get(chat)
    if not dr or dr.get('msg_id') != cq['message']['message_id']:
        return answer('That label is finished. Send new text to start another.')

    if data == 'noop':
        return answer()
    if data == 'border':
        i = label.BORDERS.index(dr['border'])
        dr['border'] = label.BORDERS[(i + 1) % len(label.BORDERS)]
        if owner and not dr.get('photo'):   # photos keep their own border; text labels remember the last one
            SETTINGS['border'] = dr['border']
            save_settings()
        dr['status'] = ''
        answer()
        return update_preview(chat, dr)
    if data in ('font', 'icon'):
        names = list(label.FONTS if data == 'font' else label.ICONS)
        dr[data] = names[(names.index(dr.get(data, names[0])) + 1) % len(names)]
        if owner:   # remembered for the next label, like the border; guests don't change the owner's style
            SETTINGS[data] = dr[data]
            save_settings()
        dr['status'] = ''
        answer()
        return update_preview(chat, dr)
    if data == 'qr':
        if dr.get('qr'):
            dr['qr'] = ''
        elif SETTINGS['qr_link']:
            dr['qr'] = SETTINGS['qr_link']
        else:
            dr['awaiting'] = 'qr'
            answer()
            return send(chat, 'Send the link or text for the QR code (e.g. your shop page). '
                              'I\'ll remember it for next time; /qr changes it.')
        dr['status'] = ''
        answer()
        return update_preview(chat, dr)
    if data == 'mode':
        dr['mode'] = 'fill' if dr['mode'] == 'fit' else 'fit'
        dr['status'] = ''
        answer()
        return update_preview(chat, dr)
    if data == 'tone':
        tones = list(label.PHOTO_TONES)
        dr['tone'] = tones[(tones.index(dr['tone']) + 1) % len(tones)]
        dr['status'] = ''
        answer()
        return update_preview(chat, dr)
    if data == 'add':
        if len(dr['lines']) >= MAX_LINES:
            return answer('That\'s the maximum of %d lines' % MAX_LINES)
        dr['awaiting'] = 'add'
        answer()
        return send(chat, 'Send the extra line(s) to add.')
    if data == 'del':
        if len(dr['lines']) <= 1:
            return answer('The label needs at least one line')
        dr['lines'].pop()
        dr['status'] = ''
        answer()
        return update_preview(chat, dr)
    if data == 'date':
        if len(dr['lines']) >= MAX_LINES:
            return answer('That\'s the maximum of %d lines' % MAX_LINES)
        dr['lines'].append(datetime.date.today().strftime(DATE_FORMAT))
        dr['status'] = ''
        answer()
        return update_preview(chat, dr)
    if data in ('copies+', 'copies-'):
        most = MAX_COPIES if owner else GUEST_MAX_COPIES
        if data == 'copies+' and dr['copies'] >= most:
            return answer('That\'s the most copies you can print at once (%d)' % most)
        dr['copies'] = max(1, min(most, dr['copies'] + (1 if data == 'copies+' else -1)))
        answer()
        return update_preview(chat, dr, image=False)
    if data == 'cancel':
        DRAFTS.pop(chat, None)
        answer('Cancelled')
        return api('editMessageCaption', {'chat_id': chat, 'message_id': cq['message']['message_id'],
                                          'caption': '✖ Cancelled', 'reply_markup': {'inline_keyboard': []}})
    if data == 'print':
        answer('Printing…')
        dr['status'] = '🖨 Printing %d…' % dr['copies']
        update_preview(chat, dr, image=False)
        # Print in the background so the buttons keep working while the Dymo runs. The design is
        # drawn again at the printer's own resolution so the dots line up 1:1.
        threading.Thread(target=print_job, daemon=True,
                         args=(chat, dr, list(dr['lines']), dr['border'], dr['copies']),
                         kwargs={'draw': draw_for(dr)}).start()
        return
    answer()


# ---------- Print channels: every post in them prints, e.g. buyer names posted by another bot ----------
# (Telegram never shows a bot its own messages, so the Whatnot extension posts through a
# second bot into a channel this bot is in.)

def on_chat_member(upd):
    chat, who = upd['chat'], upd.get('from', {}).get('id')
    if chat.get('type') != 'channel':
        return
    channels = SETTINGS.setdefault('print_channels', [])
    if upd['new_chat_member']['status'] in ('administrator', 'member'):
        if who not in ALLOWED:
            log('added to channel', chat['id'], 'by stranger', who, '- leaving')
            try:
                api('leaveChat', {'chat_id': chat['id']})
            except ApiError:
                pass
            return
        if chat['id'] not in channels:
            channels.append(chat['id'])
            save_settings()
        log('print channel added', chat['id'], chat.get('title'))
        send(who, '✅ I\'ll print every post in "%s".\n\nIts chat ID is:\n%s\n\n'
                  'Paste that into the Whatnot extension\'s Chat ID box.' % (chat.get('title', ''), chat['id']))
    elif chat['id'] in channels:
        channels.remove(chat['id'])
        save_settings()
        log('print channel removed', chat['id'])


def on_channel_post(post):
    chat = post['chat']['id']
    lines = wrap_lines(post.get('text', ''))
    if chat not in SETTINGS.get('print_channels', []) or not lines:
        return
    threading.Thread(target=print_job, daemon=True,
                     args=(chat, None, lines, SETTINGS['border'], 1, post['message_id']),
                     kwargs={'draw': draw_for(text_draft(chat, lines))}).start()


def print_job(chat, dr, lines, border, copies, reply_to=None, draw=None):
    try:
        if PAGE is None:   # CUPS wasn't ready when the bot started
            apply_printer()
        job = label.print_label(lines, border, PRINTER, PAGE_SIZE, LAYOUT, copies, lines[0], draw=draw,
                                page=page_opts(), darkness=DARKNESS.index(SETTINGS['darkness']))
        log('printed', job, lines, border, 'x%d' % copies)
        done, status = label.wait_for_job(job, PRINTER)
        result = ('✅ Printed %d' % copies if done else
                  '⚠️ Still queued. Is the printer on? %s' % status)[:900]
    except Exception as e:
        log('print failed:', e)
        result = '❌ Print failed: %s' % e
    with LOCK:
        if dr is not None and DRAFTS.get(chat) is dr:   # still the label on screen
            dr['status'] = result
            try:
                update_preview(chat, dr, image=False)
            except Exception as e:
                log('status update failed:', e)
        elif reply_to:
            send(chat, result, reply_to_message_id=reply_to)
        else:
            send(chat, result)


def main():
    me = api('getMe')
    log('running as @%s, printer %s, page %s' % (me['username'], PRINTER, PAGE_SIZE))
    start = {'command': 'start', 'description': 'How to use the label printer'}
    cancel = {'command': 'cancel', 'description': 'Discard the current label'}
    # Everyone sees the basics; the owner's own chat also lists the settings commands
    api('setMyCommands', {'commands': [start, cancel]})
    for owner in ALLOWED:
        api('setMyCommands', {'scope': {'type': 'chat', 'chat_id': owner}, 'commands': [
            start,
            {'command': 'card', 'description': 'Scan a Pokémon card and make an info label'},
            {'command': 'deepseek', 'description': 'Set the DeepSeek API key for card scanning'},
            {'command': 'qr', 'description': 'Set the link for the QR code on labels'},
            {'command': 'printer', 'description': 'Printer, label size and darkness'},
            {'command': 'align', 'description': 'Nudge where labels print on the sticker'},
            cancel]})
    offset = None
    while True:
        try:
            params = {'timeout': 50, 'allowed_updates': ['message', 'callback_query',
                                                         'channel_post', 'my_chat_member']}
            if offset:
                params['offset'] = offset
            for upd in api('getUpdates', params):
                offset = upd['update_id'] + 1
                try:
                    with LOCK:
                        if 'message' in upd:
                            on_message(upd['message'])
                        elif 'callback_query' in upd:
                            on_callback(upd['callback_query'])
                        elif 'channel_post' in upd:
                            on_channel_post(upd['channel_post'])
                        elif 'my_chat_member' in upd:
                            on_chat_member(upd['my_chat_member'])
                except Exception:
                    log('error handling update', upd.get('update_id'))
                    traceback.print_exc()
        except KeyboardInterrupt:
            sys.exit(0)
        except Exception as e:
            log('polling error:', e)
            time.sleep(5)


if __name__ == '__main__':
    main()
