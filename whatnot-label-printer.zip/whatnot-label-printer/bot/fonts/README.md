# Fonts

The **Pokémon** font option uses `PokemonSolid.ttf`, which isn't included in this
repository. "Pokemon Solid" is a fan-made font imitating the Pokémon logo lettering. It comes
with no licence file, and download sites list it as free for personal use or CC BY.

To use it, download it from [dafont.com/pokemon.font](https://www.dafont.com/pokemon.font)
and save `Pokemon Solid.ttf` here as `PokemonSolid.ttf`. Without it, the Pokémon option
falls back to the regular Sans font.

It isn't an official Pokémon font, and "Pokémon" is a trademark of Nintendo, Creatures and
Game Freak.
