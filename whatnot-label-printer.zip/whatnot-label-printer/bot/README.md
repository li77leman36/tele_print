# Telegram label printer bot

Message the bot some text or a photo. It replies with a preview of the label and buttons
for border, font, icon, QR code, extra lines, today's date and copies, then prints it. It
runs on a Raspberry Pi with a USB label printer plugged in, and also prints every post in
the print channel that the [Chrome extension](../extension) posts Whatnot buyers, chat
messages and orders to.

- The first line of a message is the big bold title, and each extra line goes underneath.
  Up to 6 lines.
- Borders: Double, Simple, Bold, Dashed or None. Fonts: Sans, Serif, Condensed, Typewriter,
  Italic and Pokémon. Icons: star, heart, lightning and Poké Ball.
- Photos are printed in black-and-white dots. You can fit the whole photo or fill the label,
  add a border, and make it lighter or darker.
- `/card` then a photo identifies a Pokémon card in any language and makes an info label.
  It needs a [DeepSeek](https://platform.deepseek.com) API key, set with `/deepseek KEY`.
- `/printer` switches printer or label size, sets darkness and adds new USB printers.
  It reads the sizes from the printer's driver, so it works with other DYMO and Zebra rolls.
- **Who can use it:** the first person to send `/start` becomes the owner (saved in
  `allowed_users.json`). Anyone else can print text and photo labels (up to 5 copies),
  while card scanning and settings stay the owner's.

## Files

| File | What it is |
|---|---|
| `bot.py` | The bot. Uses only the Python standard library, plus Pillow. |
| `label.py` | Draws labels and turns them into the printer's own raster format, so a print takes seconds on a Pi Zero. |
| `printers.py` | Reads printers and label sizes from CUPS, and adds new USB printers. |
| `config.example.env` | Copy to `config.env` and add your bot token. **Keep `config.env` private.** |
| `dymo-labelwriter-400.ppd` | DYMO LabelWriter 400 driver with a tuned full-height 57 × 32 mm size. |
| `install.sh` | One-shot setup for the Pi. |
| `fonts/`, `vendor/` | The optional Pokémon font, and the bundled QR code library. |

## You'll need

- A Raspberry Pi (a Zero W is enough), a micro-SD card (8 GB or more) and a power supply.
- A label printer CUPS can drive: DYMO LabelWriter or Zebra (ZPL/EPL).
- On a Pi Zero, a **micro-USB OTG adapter** for the printer's USB cable, in the port marked
  **USB**, not PWR. Some cheap adapters only carry power: if the printer isn't detected, try
  another adapter.

## 1. Prepare the SD card

1. Install **Raspberry Pi Imager** from raspberrypi.com/software.
2. Choose your Pi, then **Raspberry Pi OS Lite** (32-bit for a Pi Zero W), and the SD card.
3. Under **Edit settings**, set a hostname (e.g. `labelpi`), a username and password, your
   Wi-Fi, your time zone (the date button uses it), and enable SSH.
4. Write the card, put it in the Pi, plug in the printer and power up. The first boot takes a
   few minutes.

## 2. Copy the bot over and install

On your computer, in this repository:

```bash
cp bot/config.example.env bot/config.env
```

Put your printer bot's token in `bot/config.env` (`BOT_TOKEN=...`), then:

```bash
scp -r bot YOUR_USER@labelpi.local:~/label-bot
```

```bash
ssh YOUR_USER@labelpi.local
```

Then on the Pi:

```bash
cd ~/label-bot && ./install.sh
```

The installer sets up CUPS, adds the DYMO with the tuned driver, and starts the bot as a
service that runs on every boot. For another printer, add it afterwards from Telegram with
`/printer` → Printer → Find a new USB printer.

**Only one copy of the bot can run at a time** for the same token.

## Useful commands on the Pi

- Watch the logs: `journalctl -u labelbot -f`
- Restart after editing `config.env`: `sudo systemctl restart labelbot`
- Check the printer: `lpstat -p`

## Alignment

If prints come out off-centre, send `/align` and nudge the design in 0.5 mm steps with a test
print. It's saved for each printer and label size. The defaults in `config.env`
(`OFFSET_X_MM`, `OFFSET_Y_MM`) were tuned for a DYMO LabelWriter 400 with 57 × 32 mm labels.
