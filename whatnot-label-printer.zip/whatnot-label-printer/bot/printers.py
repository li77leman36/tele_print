"""What CUPS knows about the printers: installed queues, each one's label sizes (from its
driver's PPD), and adding a newly plugged-in USB label printer. Needs no sudo: the pi user
is in the lpadmin group, and CUPS serves every printer's PPD on localhost."""
import os
import re
import subprocess
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
LPINFO, LPADMIN = '/usr/sbin/lpinfo', '/usr/sbin/lpadmin'
DYMO_400_PPD = os.path.join(HERE, 'dymo-labelwriter-400.ppd')   # tuned full-height 57x32 size


def queues():
    out = subprocess.run(['lpstat', '-e'], capture_output=True, text=True, timeout=20).stdout
    return [l.strip() for l in out.splitlines() if l.strip()]


def _ppd(printer):
    url = 'http://localhost:631/printers/%s.ppd' % urllib.parse.quote(printer)
    with urllib.request.urlopen(url, timeout=15) as r:
        return r.read().decode('latin-1')


def sizes(printer):
    """The printer's label sizes in its driver's order, and the driver's default size name.
    Each size: {'name', 'label', 'w_pt', 'h_pt', 'area': (llx, lly, urx, ury), 'dpi'};
    w_pt runs across the print head."""
    ppd = _ppd(printer)
    res = re.search(r'^\*DefaultResolution:\s*(\d+)', ppd, re.M)
    dpi = int(res.group(1)) if res else 300
    labels, dims, areas = {}, {}, {}
    for m in re.finditer(r'^\*PageSize ([^/:\s]+)(?:/([^:]*))?:', ppd, re.M):
        labels[m.group(1)] = (m.group(2) or m.group(1)).strip()
    for m in re.finditer(r'^\*PaperDimension ([^/:\s]+)[^:]*:\s*"([\d.]+) ([\d.]+)"', ppd, re.M):
        dims[m.group(1)] = (float(m.group(2)), float(m.group(3)))
    for m in re.finditer(r'^\*ImageableArea ([^/:\s]+)[^:]*:\s*"([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+)"', ppd, re.M):
        areas[m.group(1)] = tuple(float(m.group(i)) for i in range(2, 6))
    out = [{'name': n, 'label': labels[n], 'w_pt': dims[n][0], 'h_pt': dims[n][1], 'area': areas[n], 'dpi': dpi}
           for n in labels if n in dims and n in areas]
    default = re.search(r'^\*DefaultPageSize:\s*(\S+)', ppd, re.M)
    return out, default.group(1) if default else (out[0]['name'] if out else None)


def find_size(printer, name):
    return next((z for z in sizes(printer)[0] if z['name'] == name), None)


def size_mm(z):
    """(width, height) in mm the way the label is read: long side across."""
    w, h = z['w_pt'] * 25.4 / 72, z['h_pt'] * 25.4 / 72
    return max(w, h), min(w, h)


def size_text(z):
    w, h = size_mm(z)
    dims = '%g x %g mm' % (round(w, 1), round(h, 1))
    name = re.sub(r'\s*\(?[\d.]+\s*x\s*[\d.]+\s*mm\)?', '', z['label']).strip(' -–')
    return '%s – %s' % (name, dims) if name and name != z['name'] else dims


# ---------- Adding a USB printer ----------

def usb_devices():
    """USB printers that are plugged in but not set up yet."""
    out = subprocess.run([LPINFO, '-l', '-v'], capture_output=True, text=True, timeout=90).stdout
    devs, cur = [], None
    for line in out.splitlines():
        m = re.match(r'Device: uri = (.*)', line)
        if m:
            cur = {'uri': m.group(1).strip()}
            devs.append(cur)
            continue
        m = re.match(r'\s+([\w-]+) = (.*)', line)
        if m and cur is not None:
            cur[m.group(1)] = m.group(2).strip()
    used = subprocess.run(['lpstat', '-v'], capture_output=True, text=True, timeout=20).stdout
    return [d for d in devs if d['uri'].startswith('usb://') and d['uri'] not in used]


def _driver(dev):
    """lpadmin arguments choosing a driver for the device, or None if no label driver fits."""
    s = (dev.get('make-and-model', '') + ' ' + dev.get('device-id', '')).lower()
    if 'labelwriter 400' in s and os.path.exists(DYMO_400_PPD):
        return ['-P', DYMO_400_PPD]
    if 'dymo' in s:
        return ['-m', 'drv:///sample.drv/dymo.ppd']
    if 'zebra' in s or 'zpl' in s or 'epl' in s:
        if 'zpl' not in s and 'epl' in s:
            return ['-m', 'drv:///sample.drv/zebraep2.ppd']
        return ['-m', 'drv:///sample.drv/zebra.ppd']
    if 'intellitech' in s:
        return ['-m', 'drv:///sample.drv/intelbar.ppd']
    if dev.get('device-id'):
        out = subprocess.run([LPINFO, '--device-id', dev['device-id'], '-m'],
                             capture_output=True, text=True, timeout=60).stdout.split()
        if out:
            return ['-m', out[0]]
    return None


def add_printer(dev):
    """Sets the device up as a CUPS printer. Returns its queue name; raises with a reason."""
    driver = _driver(dev)
    if not driver:
        raise RuntimeError('there\'s no driver for %s on the Pi. Only DYMO, Zebra and Intellitech '
                           'label printers are supported.' % (dev.get('make-and-model') or 'this printer'))
    base = re.sub(r'[^A-Za-z0-9]+', '_', dev.get('make-and-model') or 'Label_Printer').strip('_')[:40] or 'Label_Printer'
    name, n, existing = base, 2, queues()
    while name in existing:
        name, n = '%s_%d' % (base, n), n + 1
    r = subprocess.run([LPADMIN, '-p', name, '-E', '-v', dev['uri']] + driver,
                       capture_output=True, text=True, timeout=60)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout).strip() or 'lpadmin failed')
    return name
