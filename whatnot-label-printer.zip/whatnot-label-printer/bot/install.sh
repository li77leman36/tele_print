#!/bin/bash
# Sets up the Telegram label bot on a Raspberry Pi (Raspberry Pi OS Lite):
# installs CUPS + Pillow + fonts, adds the DYMO queue with the tuned 57x32 driver,
# and runs the bot as a service that starts on boot.
# Run on the Pi from this folder:  ./install.sh
set -euo pipefail
cd "$(dirname "$0")"
[ -f config.env ] || { echo "config.env missing: copy config.example.env and add BOT_TOKEN"; exit 1; }
PRINTER=$(sed -n 's/^PRINTER=//p' config.env)
PAGE_SIZE=$(sed -n 's/^PAGE_SIZE=//p' config.env)

echo "== Installing packages (takes a while on a Pi Zero)"
# IPv4 only: this network's IPv6 has no internet route, which made downloads fail
# Retries: the Raspbian download server sometimes stops answering partway through
APT="sudo apt-get -o Acquire::ForceIPv4=true -o Acquire::Retries=5 -o Acquire::http::Timeout=30"
$APT update
# cups = print system + the label filter (rastertolabel); cups-filters + ghostscript are
# used by the driver check below. The DYMO "driver" itself is dymo-labelwriter-400.ppd.
for try in 1 2 3 4; do
  $APT install -y cups cups-filters ghostscript python3-pil fonts-liberation && break
  [ "$try" = 4 ] && { echo "Package download kept failing - check the Pi's internet and re-run"; exit 1; }
  echo "== Download hiccup, retrying in 20s (attempt $((try + 1)) of 4)"; sleep 20
done
sudo usermod -aG lpadmin "$USER"

echo "== Checking the DYMO driver can turn a label into printer data"
python3 -c 'import label; open("/tmp/labelbot-test.pdf", "wb").write(label.make_pdf(label.render(["Test", "Driver check"]), 57, 32))'
if ! /usr/sbin/cupsfilter -p dymo-labelwriter-400.ppd -m application/vnd.cups-raster \
     -o PageSize="$PAGE_SIZE" /tmp/labelbot-test.pdf >/dev/null 2>/tmp/labelbot-filter.log; then
  echo "Driver check failed:"; tail -5 /tmp/labelbot-filter.log; exit 1
fi
echo "   driver OK"

echo "== Looking for the DYMO on USB"
uri=$(sudo lpinfo -v 2>/dev/null | awk '/usb:\/\/DYMO/ {print $2; exit}')
if [ -z "$uri" ]; then
  echo "DYMO not found. Plug it into the Pi's USB data port (via an OTG adapter), switch it on, and re-run."
  exit 1
fi
echo "   found $uri"
sudo lpadmin -p "$PRINTER" -E -v "$uri" -P dymo-labelwriter-400.ppd -o PageSize="$PAGE_SIZE"
sudo cupsenable "$PRINTER"
sudo cupsaccept "$PRINTER"

echo "== Installing the bot service"
sudo tee /etc/systemd/system/labelbot.service >/dev/null <<UNIT
[Unit]
Description=Telegram label printer bot
After=network-online.target cups.service
Wants=network-online.target

[Service]
User=$USER
WorkingDirectory=$PWD
ExecStart=/usr/bin/python3 $PWD/bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable --now labelbot
sleep 3
systemctl --no-pager status labelbot | head -5
echo "== Done. Send your bot a message in Telegram. Logs: journalctl -u labelbot -f"
