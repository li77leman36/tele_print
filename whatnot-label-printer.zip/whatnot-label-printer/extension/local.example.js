// Copy this file to local.js and fill it in. local.js is not committed to git, so your
// token stays private; the extension fills these in for you on install.
self.LOCAL_DEFAULTS = {
  botToken: '',  // the sender bot's token from @BotFather, e.g. 123456789:AA...
  chatId: ''     // the print channel's ID (starts with -100); the printer bot messages it to you
};
