const $ = id => document.getElementById(id);
const status = t => { $('status').textContent = t; if (t) setTimeout(() => ($('status').textContent = ''), 3000); };
const CHECKS = ['printBuyers', 'printGiveaways', 'printChat', 'chatButtons', 'orderButton'];
const TEXTS = ['botToken', 'chatId', 'chatKeyword'];
let enabled = true;

function showToggle() {
  const b = $('toggle');
  b.textContent = enabled ? 'ON - printing (click to disable)' : 'OFF - not printing (click to enable)';
  b.style.background = enabled ? '#1a7f37' : '#b42318';
}

function fill(s) {
  enabled = !!s.enabled;
  showToggle();
  CHECKS.forEach(k => ($(k).checked = !!s[k]));
  TEXTS.forEach(k => ($(k).value = s[k]));
}

const read = () => {
  const s = { enabled };
  CHECKS.forEach(k => (s[k] = $(k).checked));
  TEXTS.forEach(k => (s[k] = $(k).value.trim()));
  return s;
};

$('toggle').onclick = () => {
  enabled = !enabled;
  showToggle();
  chrome.storage.sync.set({ enabled });
};

// Ticking a box takes effect straight away; the text fields save with Save
CHECKS.forEach(k => $(k).addEventListener('change', () => chrome.storage.sync.set({ [k]: $(k).checked }, () => status('Saved'))));
$('chatKeyword').addEventListener('change', () => chrome.storage.sync.set({ chatKeyword: $('chatKeyword').value.trim() }, () => status('Saved')));

$('save').onclick = () => chrome.storage.sync.set(read(), () => status('Saved'));

$('reset').onclick = () => { fill(Object.assign({}, DEFAULTS, { enabled })); $('save').click(); };

$('test').onclick = () => {
  status('Sending…');
  chrome.runtime.sendMessage({ type: 'send', text: 'test_buyer_123', settings: read() }, r => {
    void chrome.runtime.lastError;
    status(r && r.ok ? 'Sent' : 'Failed: ' + ((r && r.error) || 'no response'));
  });
};

loadSettings().then(fill);
