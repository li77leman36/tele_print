// Whatnot → label printer: watches Whatnot live streams and sends what should be printed
// (buyers, giveaway winners, chat messages) to the print channel. Order labels are in orders.js.
(async () => {
  const NAME = '([A-Za-z0-9_.\\-]{2,40})';
  const BUY_RE = new RegExp(NAME + '\\s+(?:won the auction!|bought|purchased|just bought)');
  const GIVEAWAY_RE = new RegExp(NAME + '\\s+(?:won the giveaway|won a giveaway|won the [^\\n]{0,40}giveaway)', 'i');

  // After the extension is reloaded, the copy left running in an open tab can't reach it any more
  const alive = () => !!chrome.runtime?.id;

  let settings = await loadSettings();
  chrome.storage.onChanged.addListener(async () => {
    if (!alive()) return;
    settings = await loadSettings();
    if (!settings.chatButtons) document.querySelectorAll('.wnlp-print').forEach(b => b.remove());
  });

  const send = (text, done) => {
    if (!alive()) return;
    try {
      chrome.runtime.sendMessage({ type: 'send', text }, r => {
        void chrome.runtime.lastError;
        console.log('[whatnot-labels]', r && r.ok ? 'sent' : 'failed to send', JSON.stringify(text), r && r.error || '');
        if (done) done(r && r.ok);
      });
    } catch (e) {
      console.log('[whatnot-labels] not sent (refresh this tab):', text, e.message);
    }
  };

  // ---- Buyers and giveaway winners: lines like "kait_buys won the auction!" ----
  const namesMatching = re =>
    new Set(document.body.innerText.split('\n').map(l => (l.match(re) || [])[1]).filter(Boolean));

  // ---- Chat messages: <div data-testid="chat-message"> holding the sender and the message ----
  function readChat(el) {
    const btn = el.querySelector('button');
    let user = btn && btn.querySelector('div strong');
    let text = btn && [...btn.children].filter(c => c.tagName === 'STRONG').map(c => c.innerText).join(' ');
    if (user && text) return { user: user.innerText.trim(), text: text.replace(/\s+/g, ' ').trim() };
    // Fallback if Whatnot changes the layout: first line is the name (skipping a 1-letter avatar)
    const lines = el.innerText.split('\n').map(s => s.trim()).filter(s => s.length > 1 && s !== 'Host');
    return lines.length > 1 ? { user: lines[0], text: lines.slice(1).join(' ') } : null;
  }
  const chatLabel = m => `${m.user}\n${m.text}`;

  // 🖨 button on each message, to print that one on demand
  function addButtons() {
    if (!settings.enabled || !settings.chatButtons) return;
    document.querySelectorAll('[data-testid="chat-message"]').forEach(el => {
      if (el.querySelector('.wnlp-print')) return;
      const b = document.createElement('span');
      b.className = 'wnlp-print';
      b.textContent = '🖨';
      b.title = 'Print this message on a label';
      b.setAttribute('role', 'button');
      b.style.cssText = 'cursor:pointer;opacity:.45;margin-left:6px;font-size:14px;align-self:center;user-select:none;';
      b.onmouseenter = () => (b.style.opacity = '1');
      b.onmouseleave = () => (b.style.opacity = '.45');
      b.onclick = e => {
        e.preventDefault();
        e.stopPropagation();
        const m = readChat(el);   // read at click time: the list reuses elements as it scrolls
        if (!m) return;
        b.textContent = '…';
        send(chatLabel(m), ok => { b.textContent = ok ? '✅' : '⚠️'; setTimeout(() => (b.textContent = '🖨'), 2000); });
      };
      el.appendChild(b);
    });
  }

  let url = location.pathname;
  let settleUntil = Date.now() + 3000; // ignore whatever is already showing on load
  let prevBuyers = new Set(), prevGiveaways = new Set();
  const seenChat = new Set();
  let timer;

  const check = () => {
    if (location.pathname !== url) { url = location.pathname; settleUntil = Date.now() + 3000; }
    const live = /\/live\//.test(url);
    const quiet = !settings.enabled || !live || Date.now() < settleUntil;   // just note what's there

    const buyers = namesMatching(BUY_RE), giveaways = namesMatching(GIVEAWAY_RE);
    if (!quiet && settings.printBuyers) buyers.forEach(n => { if (!prevBuyers.has(n)) send(n); });
    if (!quiet && settings.printGiveaways) giveaways.forEach(n => { if (!prevGiveaways.has(n)) send(n); });
    prevBuyers = buyers;
    prevGiveaways = giveaways;

    // New messages arrive at the bottom; only those count, so scrolling back up through
    // older messages doesn't print them
    const els = [...document.querySelectorAll('[data-testid="chat-message"]')];
    els.forEach((el, i) => {
      const m = readChat(el);
      if (!m) return;
      const key = m.user + '\u0000' + m.text;
      if (seenChat.has(key)) return;
      seenChat.add(key);
      const kw = (settings.chatKeyword || '').trim().toLowerCase();
      if (quiet || !settings.printChat || i < els.length - 3) return;
      if (kw && !m.text.toLowerCase().startsWith(kw)) return;
      send(chatLabel(kw ? Object.assign({}, m, { text: m.text.slice(kw.length).trim() || m.text }) : m));
    });

    if (live) addButtons();
  };

  const observer = new MutationObserver(() => {
    if (!alive()) return observer.disconnect();
    clearTimeout(timer);
    timer = setTimeout(check, 400);
  });
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  console.log('[whatnot-labels] watching Whatnot');
})();
