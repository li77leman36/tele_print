// Order labels. On the Seller Hub orders table each order row gets a "🖨 Label" button that
// prints a label per item in that order: order number, item, buyer, "Item 1 of 3".
// On other order pages without "Order #…" rows, a floating button opens a panel with what it
// found on the page (all editable), and prints from that.
(() => {
  const alive = () => !!chrome.runtime?.id;
  const PRICE = /^(?:[£$€]|US\$|CA\$|A\$|AU\$)\s?\d|^\d+(?:[.,]\d{2})\s?(?:£|€|\$)$/;
  const NOT_ITEM = /^(?:sub ?total|total|shipping|postage|tax|vat|fees?|price|paid|earnings|payout|discount|tip|qty|quantity|order|buyer|seller|status|date|sold|net)\b/i;

  const isOrderPage = () => /order|sales|sold|shipment/i.test(location.pathname + location.search);

  function pageLines() {
    const root = document.querySelector('main') || document.body;
    return root.innerText.split('\n').map(s => s.trim()).filter(Boolean);
  }

  // Best guesses from the page; the panel lets you fix them before printing
  function scrape() {
    const text = (document.querySelector('main') || document.body).innerText;
    const lines = pageLines();
    let order = (text.match(/order\s*(?:number|no\.?|id|#)\s*[:#]?\s*#?\s*([A-Z0-9][A-Z0-9-]{4,})/i) || [])[1] || '';
    if (!order) {
      const seg = location.pathname.split('/').filter(Boolean);
      const i = seg.findIndex(s => /^orders?$/i.test(s));
      if (i >= 0 && seg[i + 1] && /\d/.test(seg[i + 1])) order = seg[i + 1];
    }
    let buyer = (text.match(/(?:buyer|customer|sold to|purchased by|ship(?:ping)? to)\s*:?\s*\n?\s*@?([A-Za-z0-9_.\-]{2,40})/i) || [])[1] || '';
    if (!buyer) {
      const a = (document.querySelector('main') || document.body).querySelector('a[href*="/user/"]');
      if (a) buyer = (a.getAttribute('href').split('/user/')[1] || '').split(/[/?#]/)[0];
    }
    // An item is a line just above a price that isn't a total, fee or heading
    const items = [];
    lines.forEach((l, i) => {
      const prev = lines[i - 1];
      if (PRICE.test(l) && prev && !PRICE.test(prev) && !NOT_ITEM.test(prev) && prev.length > 3 && prev !== items[items.length - 1])
        items.push(prev);
    });
    return { order, buyer, items };
  }

  function labels(order, buyer, items, count, withNames) {
    const n = items.length || count;
    return Array.from({ length: n }, (_, i) => [
      order ? `Order #${order.replace(/^#/, '')}` : 'Order',
      withNames && items[i] ? items[i] : null,
      buyer ? `@${buyer.replace(/^@/, '')}` : null,
      n > 1 ? `Item ${i + 1} of ${n}` : null
    ].filter(Boolean).join('\n'));
  }

  // ---- Orders table: a 🖨 Label button on each "Order #…" row ----
  const ORDER_RE = /Order\s*#\s*(\d{5,})/;
  const countOrders = el => (el.textContent.match(/Order\s*#\s*\d{5,}/g) || []).length;

  // Each "Order #…" text on the page, with its row: the largest element around it that holds
  // just that one order
  function orderRows() {
    const found = [];
    // Whole elements, not single text nodes: React often renders "Order #" and the number as
    // separate pieces of text. Take the innermost element that reads "Order #…".
    for (const el of document.body.querySelectorAll('*')) {
      const t = el.textContent;
      if (t.length > 40 || !ORDER_RE.test(t) || el.closest('#wnlp-orders, .wnlp-order-btn, script, style')) continue;
      if ([...el.children].some(c => ORDER_RE.test(c.textContent))) continue;
      let row = el;
      while (row.parentElement && row.parentElement !== document.body && countOrders(row.parentElement) === 1)
        row = row.parentElement;
      found.push({ el, row });
    }
    return found;
  }

  function readRow(el, row) {
    const order = (el.textContent.match(ORDER_RE) || [])[1];
    const lines = row.innerText.split('\n').map(s => s.trim()).filter(Boolean);
    const at = lines.findIndex(l => ORDER_RE.test(l));
    const title = at > 0 ? lines[at - 1] : '';
    const link = row.querySelector('a[href*="/user/"]');
    const buyer = link ? (link.textContent.trim() || (link.getAttribute('href').split('/user/')[1] || '').split(/[/?#]/)[0]) : '';
    // Items column: the first plain number after the customer
    const from = link ? lines.indexOf(link.textContent.trim()) + 1 : at + 1;
    const n = Math.min(50, parseInt(lines.slice(Math.max(from, at + 1)).find(l => /^\d{1,3}$/.test(l)) || '1', 10) || 1);
    return { order, title, buyer, n };
  }

  function addRowButtons(found) {
    found.forEach(({ el, row }) => {
      if (el.nextElementSibling && el.nextElementSibling.classList.contains('wnlp-order-btn')) return;
      const b = document.createElement('span');
      b.className = 'wnlp-order-btn';
      b.setAttribute('role', 'button');
      b.textContent = '🖨 Label';
      b.title = 'Print a label for each item in this order';
      b.style.cssText = 'display:inline-block;margin:4px 0 0;padding:2px 8px;border-radius:12px;background:#1a7f37;' +
                        'color:#fff;font:600 12px system-ui,sans-serif;cursor:pointer;user-select:none;';
      const stop = e => { e.preventDefault(); e.stopPropagation(); };
      b.onmousedown = stop;
      b.onclick = e => {
        stop(e);
        if (!alive()) return (b.textContent = 'Refresh page');
        const r = readRow(el, row);   // read at click time, in case the table changed
        const texts = labels(r.order, r.buyer, Array(r.n).fill(r.title), r.n, true);
        b.textContent = r.n > 1 ? `Sending ${r.n}…` : 'Sending…';
        chrome.runtime.sendMessage({ type: 'sendMany', texts }, res => {
          void chrome.runtime.lastError;
          b.textContent = res && res.ok ? (r.n > 1 ? `✅ ${r.n} labels` : '✅ Sent') : '⚠️ Failed';
          setTimeout(() => (b.textContent = '🖨 Label'), 3000);
        });
      };
      el.insertAdjacentElement('afterend', b);
    });
  }

  // ---- The button and panel, in a shadow root so Whatnot's styles don't touch them ----
  let host = null;

  function build() {
    host = document.createElement('div');
    host.id = 'wnlp-orders';
    host.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `
      <style>
        * { box-sizing: border-box; font: 13px system-ui, sans-serif; }
        #open { background: #1a7f37; color: #fff; border: 0; border-radius: 20px; padding: 10px 16px;
                font-weight: 700; cursor: pointer; box-shadow: 0 2px 10px rgba(0,0,0,.25); }
        #panel { width: 300px; background: #fff; color: #222; border-radius: 10px; padding: 12px;
                 box-shadow: 0 4px 20px rgba(0,0,0,.3); }
        h3 { margin: 0 0 8px; font-size: 14px; font-weight: 700; display: flex; justify-content: space-between; }
        label { display: block; font-weight: 600; margin: 8px 0 3px; }
        input[type=text], textarea { width: 100%; padding: 5px; border: 1px solid #ccc; border-radius: 5px; }
        textarea { height: 90px; resize: vertical; }
        .row { display: flex; gap: 8px; align-items: center; margin-top: 8px; }
        .hint { color: #666; font-size: 11px; margin-top: 3px; }
        #print { flex: 1; background: #1a7f37; color: #fff; border: 0; border-radius: 6px; padding: 9px; font-weight: 700; cursor: pointer; }
        #print:disabled { opacity: .6; }
        #close, #rescan { background: none; border: 0; cursor: pointer; font-size: 13px; color: #555; }
        #status { min-height: 16px; margin-top: 6px; font-size: 12px; }
        input[type=number] { width: 60px; padding: 4px; }
      </style>
      <button id="open">🖨 Print order labels</button>
      <div id="panel" hidden>
        <h3>Order labels <span><button id="rescan" title="Read the page again">↻</button><button id="close" title="Close">✕</button></span></h3>
        <label for="order">Order number</label>
        <input type="text" id="order">
        <label for="buyer">Buyer</label>
        <input type="text" id="buyer" placeholder="optional">
        <label for="items">Items, one per line</label>
        <textarea id="items" placeholder="One label is printed per line"></textarea>
        <div class="hint">Found on the page; check and fix before printing. Leave empty and set a number below to print numbered labels only.</div>
        <div class="row">
          <label style="margin:0;font-weight:400"><input type="checkbox" id="names" checked> Item names on labels</label>
        </div>
        <div class="row" id="countRow">
          <span>Labels:</span><input type="number" id="count" min="1" max="50" value="1">
        </div>
        <div class="row"><button id="print">Print</button></div>
        <div id="status"></div>
      </div>`;
    const $ = id => root.getElementById(id);
    const items = () => $('items').value.split('\n').map(s => s.trim()).filter(Boolean);
    const refresh = () => {
      const n = items().length;
      $('countRow').style.display = n ? 'none' : 'flex';
      $('print').textContent = `Print ${n || +$('count').value || 1} label${(n || +$('count').value) === 1 ? '' : 's'}`;
    };
    const fillIn = () => {
      const s = scrape();
      $('order').value = s.order;
      $('buyer').value = s.buyer;
      $('items').value = s.items.join('\n');
      $('status').textContent = s.order ? '' : 'Couldn\'t find the order number on this page; type it in.';
      refresh();
    };
    $('open').onclick = () => { $('open').hidden = true; $('panel').hidden = false; fillIn(); };
    $('close').onclick = () => { $('panel').hidden = true; $('open').hidden = false; };
    $('rescan').onclick = fillIn;
    $('items').oninput = refresh;
    $('count').oninput = refresh;
    $('print').onclick = () => {
      if (!alive()) return ($('status').textContent = 'Refresh this page, then try again.');
      const texts = labels($('order').value.trim(), $('buyer').value.trim(), items(),
                           Math.max(1, Math.min(50, +$('count').value || 1)), $('names').checked);
      $('print').disabled = true;
      $('status').textContent = `Sending ${texts.length}…`;
      try {
        chrome.runtime.sendMessage({ type: 'sendMany', texts }, r => {
          void chrome.runtime.lastError;
          $('print').disabled = false;
          $('status').textContent = r && r.ok ? `✅ Sent ${r.sent} label${r.sent === 1 ? '' : 's'} to the printer`
                                              : `⚠️ ${r ? `Sent ${r.sent || 0}, then failed: ${r.error}` : 'No response'}`;
        });
      } catch (e) {
        $('print').disabled = false;
        $('status').textContent = 'Refresh this page, then try again.';
      }
    };
    document.body.appendChild(host);
  }

  // Whatnot is a single-page app: keep checking what page we're on
  let lastCount = -1;
  async function update() {
    if (!alive()) return clearInterval(timer);
    try { await check(); } catch (e) { console.error('[whatnot-labels] order buttons:', e); }
  }
  async function check() {
    const s = await loadSettings();
    const on = s.enabled && s.orderButton;
    const found = on && !/\/live\//.test(location.pathname) ? orderRows() : [];
    if (found.length !== lastCount) console.log('[whatnot-labels] order rows found:', (lastCount = found.length));
    if (found.length) addRowButtons(found);
    if (!on) document.querySelectorAll('.wnlp-order-btn').forEach(b => b.remove());
    // The panel is for order pages without "Order #…" rows to put buttons on
    const want = on && isOrderPage() && !found.length;
    if (want && !host) build();
    if (!want && host) { host.remove(); host = null; }
  }
  const timer = setInterval(update, 1500);
  update();
})();
