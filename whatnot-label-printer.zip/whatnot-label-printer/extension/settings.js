// Shared by the popup, content script and background worker.
// Names are sent by a second bot into a channel the printer bot (@Labellllllprinter_bot) is in:
// Telegram never shows a bot its own messages, so the printer bot couldn't see names it sent itself.
const DEFAULTS = {
  enabled: true,
  botToken: '',  // the sender bot's token (not the printer bot's)
  chatId: '',    // the print channel's ID; the printer bot messages it to you when added to the channel
  // What gets printed
  printBuyers: true,      // "x won the auction!", "x bought …"
  printGiveaways: true,   // "x won the giveaway"
  printChat: false,       // every new chat message (or only ones starting with chatKeyword)
  chatKeyword: '',
  chatButtons: true,      // a 🖨 button on each chat message, to print it on demand
  orderButton: true       // "Print order labels" button on order pages
};

// Your own token and channel can live in local.js (not committed; see local.example.js)
if (typeof self !== 'undefined' && self.LOCAL_DEFAULTS) Object.assign(DEFAULTS, self.LOCAL_DEFAULTS);

// Earlier versions sent from the printer bot itself, which never prints; swap it for the sender bot
const PRINTER_BOT_ID = '8978041857:';
const loadSettings = () => new Promise(res => {
  try {
    chrome.storage.sync.get(DEFAULTS, s => {
      if (s.botToken.startsWith(PRINTER_BOT_ID)) s.botToken = DEFAULTS.botToken;
      res(s);
    });
  } catch (e) {
    // Extension was reloaded under an open tab: stay switched off until the tab is refreshed
    res(Object.assign({}, DEFAULTS, { enabled: false }));
  }
});
