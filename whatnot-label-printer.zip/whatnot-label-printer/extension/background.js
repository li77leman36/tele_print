try { importScripts('local.js'); } catch (e) { /* optional: your token and channel */ }
importScripts('settings.js');

// Fills in local.js's token and channel where nothing is saved yet, so a fresh install
// (or one loaded from a new folder) works straight away
function seedLocalDefaults() {
  if (!self.LOCAL_DEFAULTS) return;
  chrome.storage.sync.get(Object.keys(self.LOCAL_DEFAULTS), saved => {
    const fill = {};
    for (const [k, v] of Object.entries(self.LOCAL_DEFAULTS)) if (v && !saved[k]) fill[k] = v;
    if (Object.keys(fill).length) chrome.storage.sync.set(fill);
  });
}
chrome.runtime.onInstalled.addListener(seedLocalDefaults);
chrome.runtime.onStartup.addListener(seedLocalDefaults);

// Keeps the ON/OFF badge on the toolbar icon in sync with the setting.
const setBadge = () =>
  loadSettings().then(({ enabled }) => {
    chrome.action.setBadgeText({ text: enabled ? 'ON' : 'OFF' });
    chrome.action.setBadgeBackgroundColor({ color: enabled ? '#1a7f37' : '#b42318' });
  });
chrome.runtime.onStartup.addListener(setBadge);
chrome.runtime.onInstalled.addListener(setBadge);
chrome.storage.onChanged.addListener(setBadge);

// Posts a label's text to the print channel; the printer bot prints every post there,
// one label line per text line. Done here rather than in the page so the request isn't
// subject to whatnot.com's CORS/CSP rules.
async function sendToTelegram(text, s) {
  if (!s.botToken || !s.chatId) return { ok: false, error: 'Set a bot token and chat ID first' };
  try {
    const r = await fetch(`https://api.telegram.org/bot${s.botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: s.chatId, text })
    });
    const j = await r.json();
    return j.ok ? { ok: true } : { ok: false, error: j.description || `HTTP ${r.status}` };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !['sendBuyer', 'send', 'sendMany'].includes(msg.type)) return;
  (async () => {
    // The popup passes the settings being edited so a test uses them before they're saved
    const s = msg.settings || await loadSettings();
    if (msg.type !== 'sendMany') return sendToTelegram(msg.text || msg.name, s);
    // One label per text, in order; spaced out so they print in that order
    let sent = 0;
    for (const text of msg.texts) {
      const r = await sendToTelegram(text, s);
      if (!r.ok) return { ok: false, sent, error: r.error };
      sent++;
      await sleep(600);
    }
    return { ok: true, sent };
  })().then(sendResponse);
  return true;
});
